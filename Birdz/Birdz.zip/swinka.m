function swinka(px,py,xCialo,yCialo)

global ucho_x;
global ucho_y;
global cialo_x;
global cialo_y;
global oko_x;
global oko_y;
global zrenica_x;
global zrenica_y;
global nos_x;
global nos_y;
global dziurka_x;
global dziurka_y;

hold on
argument = 0:0.01:2*pi;

ucho_x = (px/4)*cos(argument);
ucho_y = (px/4)*sin(argument);

plot(ucho_x+xCialo+(5/8)*px,ucho_y+yCialo+(4/5)*py);
fill(ucho_x+xCialo+(5/8)*px,ucho_y+yCialo+(4/5)*py,'g');

plot(ucho_x+xCialo-(5/8)*px,ucho_y+yCialo+(4/5)*py);
fill(ucho_x+xCialo-(5/8)*px,ucho_y+yCialo+(4/5)*py,'g');

cialo_x = px*cos(argument);
cialo_y = py*sin(argument);

plot(cialo_x+xCialo,cialo_y+yCialo);
fill(cialo_x+xCialo,cialo_y+yCialo,'g');

oko_x = ((7*px)/20)*cos(argument);
oko_y = ((7*py)/20)*sin(argument);

plot(oko_x+xCialo+(3/4)*px,oko_y+yCialo+(1/4)*py);
fill(oko_x+xCialo+(3/4)*px,oko_y+yCialo+(1/4)*py,'w');

plot(oko_x+xCialo-(3/4)*px,oko_y+yCialo+(1/4)*py);
fill(oko_x+xCialo-(3/4)*px,oko_y+yCialo+(1/4)*py,'w');

zrenica_x = (px/10)*cos(argument);
zrenica_y = (py/10)*sin(argument);

plot(zrenica_x+xCialo+(3/4)*px,zrenica_y+yCialo+(1/4)*py);
fill(zrenica_x+xCialo+(3/4)*px,zrenica_y+yCialo+(1/4)*py,'k');

plot(zrenica_x+xCialo-(3/4)*px,zrenica_y+yCialo+(1/4)*py);
fill(zrenica_x+xCialo-(3/4)*px,zrenica_y+yCialo+(1/4)*py,'k');

nos_x = ((5*px)/8)*cos(argument);
nos_y = ((4*py)/10)*sin(argument);

plot(nos_x+xCialo,nos_y+yCialo);
fill(nos_x+xCialo,nos_y+yCialo,'g');

dziurka_x = ((3*px)/20)*cos(argument);
dziurka_y = ((3*py)/20)*sin(argument);

plot(dziurka_x+xCialo+(1/4)*px,dziurka_y+yCialo+(1/10)*py);
fill(dziurka_x+xCialo+(1/4)*px,dziurka_y+yCialo+(1/10)*py,'k');

dziurkaa_x = ((3*px)/20)*cos(argument);
dziurkaa_y = (py/5)*sin(argument);

plot(dziurkaa_x+xCialo-(1/4)*px,dziurkaa_y+yCialo+(1/10)*py);
fill(dziurkaa_x+xCialo-(1/4)*px,dziurkaa_y+yCialo+(1/10)*py,'k');

end
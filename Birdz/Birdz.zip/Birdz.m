function varargout = Birdz(varargin)
% Adam Denes [221672]
% BIRDZ MATLAB code for Birdz.fig
%      BIRDZ, by itself, creates a new BIRDZ or raises the existing
%      singleton*.
%
%      H = BIRDZ returns the handle to a new BIRDZ or the handle to
%      the existing singleton*.
%
%      BIRDZ('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BIRDZ.M with the given input arguments.
%
%      BIRDZ('Property','Value',...) creates a new BIRDZ or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Birdz_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Birdz_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Birdz

% Last Modified by GUIDE v2.5 12-Jun-2015 06:42:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Birdz_OpeningFcn, ...
                   'gui_OutputFcn',  @Birdz_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Birdz is made visible.
function Birdz_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Birdz (see VARARGIN)

% Choose default command line output for Birdz
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Birdz wait for user response (see UIRESUME)
% uiwait(handles.figure1);

global highscore_1;
global highscore_2;

highscore_1 = 0;
highscore_2 = 0;

axis([0 1164 0 700]);
hold on
fill([0 0 1164 1164],[0 700 700 0],'k');
set(handles.Play,'visible','off');
set(handles.Help,'visible','off');
set(handles.uipanel1,'visible','off');
set(handles.text2,'visible','off');
set(handles.text3,'visible','off');
set(handles.edit1,'visible','off');
set(handles.edit2,'visible','off');
set(handles.Throw_1,'visible','off');
set(handles.Level_1,'visible','off');
set(handles.Level_2,'visible','off');
set(handles.Back,'visible','off');
set(handles.Replay_1,'visible','off');
set(handles.Exit,'visible','off');
set(handles.Levels,'visible','off');
set(handles.Score_1,'visible','off');
set(handles.Throw_2,'visible','off');
set(handles.Replay_2,'visible','off');
set(handles.Highscore,'visible','off');
set(handles.Highscore_1,'visible','off');

% --- Executes on button press in Start.

function Start_Callback(~, ~, handles)
% hObject    handle to Start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.Start,'visible','off');
global Napisy_01;
global Napisy_02;
global Napisy_03;
global Napisy_04;
global Napisy_05;
global Napisy_06;
global Napisy_07;
global Napisy_08;
global Napisy_09;
global Napisy_010;
global Napisy_011;
global Napisy_012;
global Napisy_013;
global Napisy_014;
global Napisy_015;
global Napisy_016;
global Napisy_017;
global Napisy_018;
global Napisy_019;
global Napisy_020;
global Napisy_1;
global Napisy_2;
global Napisy_3;
global Napisy_4;
global Napisy_5;
global Napisy_6;
global Napisy_7;
global Napisy_8;
global Napisy_9;
global Napisy_10;
global Napisy_11;
global Napisy_12;
global Napisy_13;
global Napisy_14;
global Napisy_15;
global Napisy_16;
global Napisy_17;
global Napisy_18;
global Napisy_19;
global Napisy_20;
global Main_Menu;
global main_menu;
global lvl;
lvl = 0;
hold on
axis([0 1164 0 700]);
set(gca,'YDir','normal');
Napisy_01 = imread('Napisy_1.JPG');
Napisy_02 = imread('Napisy_2.JPG');
Napisy_03 = imread('Napisy_3.JPG');
Napisy_04 = imread('Napisy_4.JPG');
Napisy_05 = imread('Napisy_5.JPG');
Napisy_06 = imread('Napisy_6.JPG');
Napisy_07 = imread('Napisy_7.JPG');
Napisy_08 = imread('Napisy_8.JPG');
Napisy_09 = imread('Napisy_9.JPG');
Napisy_010 = imread('Napisy_10.JPG');
Napisy_011 = imread('Napisy_11.JPG');
Napisy_012 = imread('Napisy_12.JPG');
Napisy_013 = imread('Napisy_13.JPG');
Napisy_014 = imread('Napisy_14.JPG');
Napisy_015 = imread('Napisy_15.JPG');
Napisy_016 = imread('Napisy_16.JPG');
Napisy_017 = imread('Napisy_17.JPG');
Napisy_018 = imread('Napisy_18.JPG');
Napisy_019 = imread('Napisy_19.JPG');
Napisy_020 = imread('Napisy_20.JPG');
Main_Menu = imread('Main_Menu.JPG');
set(handles.Play,'visible','off');
set(handles.Help,'visible','off');
set(handles.uipanel1,'visible','off');
set(handles.text2,'visible','off');
set(handles.text3,'visible','off');
set(handles.edit1,'visible','off');
set(handles.edit2,'visible','off');
set(handles.Throw_1,'visible','off');
set(handles.Level_1,'visible','off');
Napisy_1 = imshow(Napisy_01);
pause(0.1);
Napisy_2 = imshow(Napisy_02);
pause(0.1);
Napisy_3 = imshow(Napisy_03);
pause(0.1);
Napisy_4 = imshow(Napisy_04);
pause(0.1);
Napisy_5 = imshow(Napisy_05);
pause(0.1);
Napisy_6 = imshow(Napisy_06);
pause(0.1);
Napisy_7 = imshow(Napisy_07);
pause(0.1);
Napisy_8 = imshow(Napisy_08);
pause(0.1);
Napisy_9 = imshow(Napisy_09);
pause(0.1);
Napisy_10 = imshow(Napisy_010);
pause(0.5);
set(Napisy_10,'visible','off');
pause(0.1);
set(Napisy_9,'visible','off');
pause(0.1);
set(Napisy_8,'visible','off');
pause(0.1);
set(Napisy_7,'visible','off');
pause(0.1);
set(Napisy_6,'visible','off');
pause(0.1);
set(Napisy_5,'visible','off');
pause(0.1);
set(Napisy_4,'visible','off');
pause(0.1);
set(Napisy_3,'visible','off');
pause(0.1);
set(Napisy_2,'visible','off');
pause(0.2);
Napisy_11 = imshow(Napisy_011);
pause(0.1);
Napisy_12 = imshow(Napisy_012);
pause(0.1);
Napisy_13 = imshow(Napisy_013);
pause(0.1);
Napisy_14 = imshow(Napisy_014);
pause(0.1);
Napisy_15 = imshow(Napisy_015);
pause(0.1);
Napisy_16 = imshow(Napisy_016);
pause(0.1);
Napisy_17 = imshow(Napisy_017);
pause(0.1);
Napisy_18 = imshow(Napisy_018);
pause(0.1);
set(Napisy_17,'visible','off');
Napisy_19 = imshow(Napisy_019);
pause(0.1);
Napisy_20 = imshow(Napisy_020);
pause(0.5);
set(Napisy_20,'visible','off');
pause(0.1);
set(Napisy_19,'visible','off');
pause(0.1);
set(Napisy_18,'visible','off');
pause(0.1);
set(Napisy_17,'visible','off');
pause(0.1);
set(Napisy_16,'visible','off');
pause(0.1);
set(Napisy_15,'visible','off');
pause(0.1);
set(Napisy_14,'visible','off');
pause(0.1);
set(Napisy_13,'visible','off');
pause(0.1);
set(Napisy_12,'visible','off');
pause(0.1);
set(Napisy_11,'visible','off');
pause(0.1);
set(Napisy_1,'visible','off');
main_menu = imshow(Main_Menu);
set(handles.Play,'visible','on');
set(handles.Help,'visible','on');


% --- Executes on button press in Play.
function Play_Callback(~, ~, handles)
% hObject    handle to Play (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Level_Select;
global level_select;
global main_menu;
global lvl;

hold on
axis([0 1164 0 700]);
set(gca,'YDir','normal');

set(handles.Play,'visible','off');
set(handles.Help,'visible','off');
set(handles.uipanel1,'visible','off');
set(handles.text2,'visible','off');
set(handles.text3,'visible','off');
set(handles.edit1,'visible','off');
set(handles.edit2,'visible','off');
set(handles.Throw_1,'visible','off');
set(main_menu,'visible','off');
if lvl == 0
    Level_Select = imread('Level_Select.JPG');
    level_select = imshow(Level_Select);
    set(handles.Level_1,'visible','on');
elseif lvl == 1    
    Level_Select = imread('Level_Select_2.JPG');
    level_select = imshow(Level_Select);
    set(handles.Level_1,'visible','on');
    set(handles.Level_2,'visible','on');
end

% --- Executes on button press in Level_1.
function Level_1_Callback(~, ~, handles)
% hObject    handle to Level_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global i;
global B;
global C;
global D;
global E;
global F;
global G;
global H;
global I;
global J;
global K;
global BB_1;
global BB_2;
global BB_3;
global BB_4;
global CC_1;
global CC_2;
global CC_3;
global CC_4;
global DD_1;
global EE_1;
global EE_2;
global EE_3;
global FF_1;
global GG_1;
global HH_1;
global II_1;
global JJ_1;
global KK_1;
global KK_2;
global KK_3;
global KK_4;
global KK_5;
global KK_6;
global KK_7;
global KK_8;
global KK_9;
global KK_10;
global KK_11;
global KK_12;
global KK_13;
global KK_14;
global KK_15;
global KK_16;
global KK_17;
global KK_18;
global TS_1;
global TS_2;
global TS_3;
global Ts_1;
global Ts_2;
global Ts_3;
global Ex_1;
global Ex_2;
global Ex_3;
global Ex_4;
global Ex_5;
global Ex_6;
global Ex_7;
global Ex_8;
global Ex_9;
global Ex_10;
global Ex_11;
global Ex_12;
global Ex_13;
global Ex_14;
global Ex_15;
global Exp_1;
global Exp_2;
global Exp_3;
global Exp_4;
global Exp_5;
global Exp_6;
global Exp_7;
global Exp_8;
global Exp_9;
global Exp_10;
global Exp_11;
global Exp_12;
global Exp_13;
global Exp_14;
global Exp_15;
global Fail_Sc;
global Fail_sc;
global Win_Sc_1;
global Win_Sc_2;
global Win_Sc_3;
global Win_sc_1;
global Win_sc_2;
global Win_sc_3;
global Red;
global Blues;
global Chuck;
global Redd;
global Bluess;
global Chuckk;
global level_select;
global score_1;
global Level_1_1;
global Level_1_2;
global Level_1_3;
global Level_1_4;
global Level_1_5;
global Level_1_6;
global Level_1_7;
global level_1_1;
global level_1_2;
global level_1_3;
global level_1_4;
global level_1_5;
global level_1_6;
global level_1_7;

set(level_select,'visible','off');
set(handles.Level_1,'visible','off');
set(handles.Level_2,'visible','off');

Level_1_1 = imread('Level_1_1.JPG');
level_1_1 = imshow(Level_1_1);
Level_1_2 = imread('Level_1_2.JPG');
level_1_2 = imshow(Level_1_2);
set(level_1_2,'visible','off');
Level_1_3 = imread('Level_1_3.JPG');
level_1_3 = imshow(Level_1_3);
set(level_1_3,'visible','off');
Level_1_4 = imread('Level_1_4.JPG');
level_1_4 = imshow(Level_1_4);
set(level_1_4,'visible','off');
Level_1_5 = imread('Level_1_5.JPG');
level_1_5 = imshow(Level_1_5);
set(level_1_5,'visible','off');
Level_1_6 = imread('Level_1_6.JPG');
level_1_6 = imshow(Level_1_6);
set(level_1_6,'visible','off');
Level_1_7 = imread('Level_1_7.JPG');
level_1_7 = imshow(Level_1_7);
set(level_1_7,'visible','off');
B = imread('Drewno_Poziom.JPG'); % 72 x 23
C = imread('Drewno_Pion.JPG'); % 23 x 72
D = imread('Drewno_Pion_Dlugie.JPG'); % 23 x 238
E = imread('Lod_Pion.JPG'); % 22 x 98
F = imread('Lod_Poziom_Dlugi.JPG'); % 168 x 20
G = imread('Kamien_Pion.JPG'); % 34 x 72
H = imread('Kamien_Poziom.JPG'); % 72 x 34
I = imread('Lodowy_Trojkat.JPG'); % 82 x 82
J = imread('TNT.JPG');  % 50 x 50
K = imread('Lodowa_Kostka.JPG'); % 22 x 20
TS_1 = imread('Tlo_Swini_1.JPG'); % 50 x 50
TS_2 = imread('Tlo_Swini_2.JPG'); % 50 x 50
TS_3 = imread('Tlo_Swini_3.JPG'); % 50 x 50
Ex_1 = imread('Explosion_1.JPG');
Ex_2 = imread('Explosion_2.JPG');
Ex_3 = imread('Explosion_3.JPG');
Ex_4 = imread('Explosion_4.JPG');
Ex_5 = imread('Explosion_5.JPG');
Ex_6 = imread('Explosion_6.JPG');
Ex_7 = imread('Explosion_7.JPG');
Ex_8 = imread('Explosion_8.JPG');
Ex_9 = imread('Explosion_9.JPG');
Ex_10 = imread('Explosion_10.JPG');
Ex_11 = imread('Explosion_11.JPG');
Ex_12 = imread('Explosion_12.JPG');
Ex_13 = imread('Explosion_13.JPG');
Ex_14 = imread('Explosion_14.JPG');
Ex_15 = imread('Explosion_15.JPG');
Redd = imread('Red.JPG');
Bluess = imread('Blues.JPG');
Chuckk = imread('Chuck.JPG');
HH_1 = imagesc(666,171,H);
BB_1 = imagesc(900,242,B);
BB_2 = imagesc(828,242,B);
CC_1 = imagesc(828,171,C);
CC_2 = imagesc(949.5,171,C);
CC_3 = imagesc(949.5,264.5,C);
CC_4 = imagesc(949.5,336.5,C);
BB_3 = imagesc(949.5,408.5,B);
DD_1 = imagesc(1071,171,D);
BB_4 = imagesc(1021.5,408.5,B);
EE_1 = imagesc(1010,171,E);
FF_1 = imagesc(937.5,528,F);
II_1 = imagesc(979.5,269,I);
GG_1 = imagesc(883,265,G);
JJ_1 = imagesc(875,335.5,J);
KK_1 = imagesc(971.5,431,K);
KK_2 = imagesc(1049.5,431,K);
EE_2 = imagesc(949.5,431,E);
EE_3 = imagesc(1071.5,431,E);
KK_3 = imagesc(937.5,548,K);
KK_4 = imagesc(1083.5,548,K);
KK_5 = imagesc(959.5,548,K);
KK_6 = imagesc(1061.5,548,K);
KK_7 = imagesc(948.5,568,K);
KK_8 = imagesc(970.5,568,K);
KK_9 = imagesc(926.5,568,K);
KK_10 = imagesc(1072.5,568,K);
KK_11 = imagesc(1094.5,568,K);
KK_12 = imagesc(1050.5,568,K);
KK_13 = imagesc(948.5,588,K);
KK_14 = imagesc(915.5,588,K);
KK_15 = imagesc(981.5,588,K);
KK_16 = imagesc(1072.5,588,K);
KK_17 = imagesc(1105.5,588,K);
KK_18 = imagesc(1039.5,588,K);
set(gca,'YDir','normal');
swinka(25,25,702,229.5);
swinka(25,25,900,196);
swinka(25,25,1021.5,456);
Ts_1 = imagesc(673,204.5,TS_1);
set(Ts_1,'visible','off');
Ts_2 = imagesc(871,171,TS_2);
set(Ts_2,'visible','off');
Ts_3 = imagesc(992.5,431,TS_3);
set(Ts_3,'visible','off');
Exp_1 = imagesc(828,243,Ex_1);
set(Exp_1,'visible','off');
Exp_2 = imagesc(828,243,Ex_2);
set(Exp_2,'visible','off');
Exp_3 = imagesc(828,243,Ex_3);
set(Exp_3,'visible','off');
Exp_4 = imagesc(828,243,Ex_4);
set(Exp_4,'visible','off');
Exp_5 = imagesc(828,243,Ex_5);
set(Exp_5,'visible','off');
Exp_6 = imagesc(828,243,Ex_6);
set(Exp_6,'visible','off');
Exp_7 = imagesc(828,243,Ex_7);
set(Exp_7,'visible','off');
Exp_8 = imagesc(827,243,Ex_8);
set(Exp_8,'visible','off');
Exp_9 = imagesc(827,243,Ex_9);
set(Exp_9,'visible','off');
Exp_10 = imagesc(827,243,Ex_10);
set(Exp_10,'visible','off');
Exp_11 = imagesc(827,243,Ex_11);
set(Exp_11,'visible','off');
Exp_12 = imagesc(827,243,Ex_12);
set(Exp_12,'visible','off');
Exp_13 = imagesc(827,243,Ex_13);
set(Exp_13,'visible','off');
Exp_14 = imagesc(827,243,Ex_14);
set(Exp_14,'visible','off');
Exp_15 = imagesc(827,243,Ex_15);
set(Exp_15,'visible','off');
Fail_Sc = imread('Fail_Screen.JPG'); % 364 x 340
Fail_sc = imagesc(400,260,Fail_Sc);
set(Fail_sc,'visible','off');
Win_Sc_1 = imread('Win_Screen_1.PNG');
Win_sc_1 = imagesc(400,260,Win_Sc_1);
set(Win_sc_1,'visible','off');
Win_Sc_2 = imread('Win_Screen_2.PNG');
Win_sc_2 = imagesc(400,260,Win_Sc_2);
set(Win_sc_2,'visible','off');
Win_Sc_3 = imread('Win_Screen_3.PNG');
Win_sc_3 = imagesc(400,260,Win_Sc_3);
set(Win_sc_3,'visible','off');
Red = imagesc(11,231,Redd);
set(Red,'visible','off');
Chuck = imagesc(11,231,Chuckk);
set(Chuck,'visible','off');
Blues = imagesc(11,231,Bluess);
set(Blues,'visible','off');
i = 0;
score_1 = 0;
set(handles.Play,'visible','off');
set(handles.uipanel1,'visible','on');
set(handles.text2,'visible','on');
set(handles.text3,'visible','on');
set(handles.edit1,'visible','on');
set(handles.edit2,'visible','on');
set(handles.Throw_1,'visible','on');
set(handles.edit1,'string',0);
set(handles.edit2,'string',0);

% --- Executes on button press in Help.
function Help_Callback(~, ~, handles)
% hObject    handle to Help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Help;
global Help_sc;
global main_menu;

hold on
axis([0 1164 0 700]);
set(gca,'YDir','normal');

Help = imread('Help.JPG');
Help_sc = imshow(Help);
set(handles.Play,'visible','off');
set(handles.Help,'visible','off');
set(handles.uipanel1,'visible','off');
set(handles.text2,'visible','off');
set(handles.text3,'visible','off');
set(handles.edit1,'visible','off');
set(handles.edit2,'visible','off');
set(handles.Throw_1,'visible','off');
set(main_menu,'visible','off');
set(handles.Back,'visible','on');

% --- Executes on button press in Back.
function Back_Callback(~, ~, handles)
% hObject    handle to Back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Main_Menu;
global main_menu;

hold on
axis([0 1164 0 700]);
set(handles.Back,'visible','off');
Main_Menu = imread('Main_Menu.JPG');
main_menu = imshow(Main_Menu);
set(handles.Play,'visible','on');
set(handles.Help,'visible','on');
set(handles.Score_1,'visible','off');

% --- Outputs from this function are returned to the command line.
function varargout = Birdz_OutputFcn(~, ~, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Throw_1.
function Throw_1_Callback(~, ~, handles)
% hObject    handle to Throw_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global highscore_1;
global score_1;
global i;
global BB_1;
global BB_2;
global BB_3;
global BB_4;
global CC_1;
global CC_2;
global CC_3;
global CC_4;
global DD_1;
global EE_1;
global EE_2;
global EE_3;
global FF_1;
global GG_1;
global HH_1;
global II_1;
global JJ_1;
global KK_1;
global KK_2;
global KK_3;
global KK_4;
global KK_5;
global KK_6;
global KK_7;
global KK_8;
global KK_9;
global KK_10;
global KK_11;
global KK_12;
global KK_13;
global KK_14;
global KK_15;
global KK_16;
global KK_17;
global KK_18;
global Exp_1;
global Ts_1;
global Ts_2;
global Ts_3;
global Exp_2;
global Exp_3;
global Exp_4;
global Exp_5;
global Exp_6;
global Exp_7;
global Exp_8;
global Exp_9;
global Exp_10;
global Exp_11;
global Exp_12;
global Exp_13;
global Exp_14;
global Exp_15;
global Fail_sc;
global Red;
global Blues;
global Chuck;
global Win_sc_1;
global Win_sc_2;
global Win_sc_3;
global lvl;
global level_1_2;
global level_1_3;
global level_1_4;
global level_1_5;
global level_1_6;
global level_1_7;

i = i + 1;

if i == 1
    set(level_1_2,'visible','on');
elseif i == 2
    set(level_1_3,'visible','on');
    set(level_1_2,'visible','off');
elseif i == 3 
    set(level_1_4,'visible','on');
    set(level_1_3,'visible','off');
elseif i == 4
    set(level_1_5,'visible','on');
    set(level_1_4,'visible','off');
elseif i == 5
    set(level_1_6,'visible','on');
    set(level_1_5,'visible','off');
elseif i == 6
    set(level_1_7,'visible','on');
    set(level_1_6,'visible','off');
end

if i == 2 || i == 5
    set(Chuck,'visible','on');
elseif i == 3 || i == 6
    set(Blues,'visible','on');
else 
    set(Red,'visible','on');
end

[X,Y] = ginput(1);
    
if X < 26
    z = [0 26 0;Y 252 Y-252];
elseif X <= 506
    z = [X 26 X-26;Y 252 Y-252];
else
    z = [506 26 480;Y 252 Y-252];
end

Z = sqrt((z(1,3)^2)+(z(2,3)^2));
  
if X < 26
    return
elseif z(2,3) < 0
    return
else
    if z(2,3)/Z == 1
        a = 90;
    elseif z(2,3)/Z >= 0.9996
        a = 89;
    elseif z(2,3)/Z >= 0.9990
        a = 88;
    elseif z(2,3)/Z >= 0.9981
        a = 87;
    elseif z(2,3)/Z >= 0.9969
        a = 86;
    elseif z(2,3)/Z >= 0.99535
        a = 85;
    elseif z(2,3)/Z >= 0.9935
        a = 84;
    elseif z(2,3)/Z >= 0.9914
        a = 83;
    elseif z(2,3)/Z >= 0.9890
        a = 82;
    elseif z(2,3)/Z >= 0.98625
        a = 81;
    elseif z(2,3)/Z >= 0.9832
        a = 80;
    elseif z(2,3)/Z >= 0.97985
        a = 79;
    elseif z(2,3)/Z >= 0.97625
        a = 78;
    elseif z(2,3)/Z >= 0.97235
        a = 77;
    elseif z(2,3)/Z >= 0.9681
        a = 76;
    elseif z(2,3)/Z >= 0.9636
        a = 75;
    elseif z(2,3)/Z >= 0.9588	
        a = 74;
    elseif z(2,3)/Z >= 0.9537	
        a = 73;
    elseif z(2,3)/Z >= 0.9483	
        a = 72;
    elseif z(2,3)/Z >= 0.9426	
        a = 71;
    elseif z(2,3)/Z >= 0.93665	
        a = 70;
    elseif z(2,3)/Z >= 0.9304	
        a = 69;
    elseif z(2,3)/Z >= 0.92385	
        a = 68;
    elseif z(2,3)/Z >= 0.917	
        a = 67;
    elseif z(2,3)/Z >= 0.9099	
        a = 66;
    elseif z(2,3)/Z >= 0.90255	
        a = 65;
    elseif z(2,3)/Z >= 0.8949	
        a = 64;
    elseif z(2,3)/Z >= 0.88695	
        a = 63;
    elseif z(2,3)/Z >= 0.87875	
        a = 62;
    elseif z(2,3)/Z >= 0.8703	
        a = 61;
    elseif z(2,3)/Z >= 0.8616	
        a = 60;
    elseif z(2,3)/Z >= 0.8526	
        a = 59;
    elseif z(2,3)/Z >= 0.84335	
        a = 58;
    elseif z(2,3)/Z >= 0.83385	
        a = 57;
    elseif z(2,3)/Z >= 0.8241	
        a = 56;
    elseif z(2,3)/Z >= 0.8141	
        a = 55;
    elseif z(2,3)/Z >= 0.8038	
        a = 54;
    elseif z(2,3)/Z >= 0.7933	
        a = 53;
    elseif z(2,3)/Z >= 0.78255	
        a = 52;
    elseif z(2,3)/Z >= 0.77155	
        a = 51;
    elseif z(2,3)/Z >= 0.76035	
        a = 50;
    elseif z(2,3)/Z >= 0.7489	
        a = 49;
    elseif z(2,3)/Z >= 0.73725	
        a = 48;
    elseif z(2,3)/Z >= 0.72535
        a = 47;
    elseif z(2,3)/Z >= 0.7132	
        a = 46;
    elseif z(2,3)/Z >= 0.7009
        a = 45;
    elseif z(2,3)/Z >= 0.68835
        a = 44;
    elseif z(2,3)/Z >= 0.67555
        a = 43;
    elseif z(2,3)/Z >= 0.6626
        a = 42;
    elseif z(2,3)/Z >= 0.64945
        a = 41;
    elseif z(2,3)/Z >= 0.63605
        a = 40;
    elseif z(2,3)/Z >= 0.6225
        a = 39;
    elseif z(2,3)/Z >= 0.60875
        a = 38;
    elseif z(2,3)/Z >= 0.5948
        a = 37;
    elseif z(2,3)/Z >= 0.5807
        a = 36;
    elseif z(2,3)/Z >= 0.5664
        a = 35;
    elseif z(2,3)/Z >= 0.5519
        a = 34;
    elseif z(2,3)/Z >= 0.53725
        a = 33;
    elseif z(2,3)/Z >= 0.52245
        a = 32;
    elseif z(2,3)/Z >= 0.5075
        a = 31;
    elseif z(2,3)/Z >= 0.4924
        a = 30;
    elseif z(2,3)/Z >= 0.47715
        a = 29;
    elseif z(2,3)/Z >= 0.46175
        a = 28;
    elseif z(2,3)/Z >= 0.4462
        a = 27;
    elseif z(2,3)/Z >= 0.4305
        a = 26;
    elseif z(2,3)/Z >= 0.41465
        a = 25;
    elseif z(2,3)/Z >= 0.3987
        a = 24;
    elseif z(2,3)/Z >= 0.38265
        a = 23;
    elseif z(2,3)/Z >= 0.3665
        a = 22;
    elseif z(2,3)/Z >= 0.3502
        a = 21;
    elseif z(2,3)/Z >= 0.3338
        a = 20;
    elseif z(2,3)/Z >= 0.3173
        a = 19;
    elseif z(2,3)/Z >= 0.3007
        a = 18;
    elseif z(2,3)/Z >= 0.284
        a = 17;
    elseif z(2,3)/Z >= 0.2672
        a = 16;
    elseif z(2,3)/Z >= 0.25035
        a = 15;
    elseif z(2,3)/Z >= 0.23345
        a = 14;
    elseif z(2,3)/Z >= 0.21645
        a = 13;
    elseif z(2,3)/Z >= 0.19935
        a = 12;
    elseif z(2,3)/Z >= 0.1822
        a = 11;
    elseif z(2,3)/Z >= 0.165
        a = 10;
    elseif z(2,3)/Z >= 0.1478
        a = 9;
    elseif z(2,3)/Z >= 0.13055
        a = 8;
    elseif z(2,3)/Z >= 0.1132
        a = 7;
    elseif z(2,3)/Z >= 0.09585
        a = 6;
    elseif z(2,3)/Z >= 0.0785
        a = 5;
    elseif z(2,3)/Z >= 0.06105
        a = 4;
    elseif z(2,3)/Z >= 0.0436
        a = 3;
    elseif z(2,3)/Z >= 0.0262
        a = 2;
    elseif z(2,3)/Z >= 0.00875
        a = 1;
    elseif z(2,3)/Z >= 0
        a = 0;
    end
end
    
    set(handles.edit1,'string',z(1,3)/4);
    set(handles.edit2,'string',a);
    
    V0 = str2num(get(handles.edit1,'string'));
    rad = str2num(get(handles.edit2,'string'));
    
    alfa = rad*pi/180;
    g = 9.81;
    h0 = 252;
        
    V0y = @(alfa) V0*sin(alfa);
    predkosc_poczatkowa_y = V0y(alfa);
    
    V0x = @(alfa) V0*cos(alfa);
    predkosc_poczatkowa_x = V0x(alfa);
    
    hw = (predkosc_poczatkowa_y^2)/(2*g);
    hs = h0+hw; 
    
    tw = predkosc_poczatkowa_y/g;
    ts = (((2*h0)/g)+((predkosc_poczatkowa_y^2)/(g^2)))^(1/2);
    tr = tw+ts;
    t = linspace(0,tr);
    
    Vy = @(t) predkosc_poczatkowa_y-g.*t;
    predkosc_y = Vy(t);
    
    x = @(t) predkosc_poczatkowa_x.*t+26;
    polozenie_x = x(t);
    
    y = @(t) (predkosc_poczatkowa_y.*t-((g*(t.^2))/2))+h0;
    polozenie_y = y(t);
    
    h = line('color','k','marker','o','Erase','xor','MarkerFace','red','MarkerSize',20);
    
    if i == 2 || i == 5 
        set(h,'marker','^','MarkerFace','yellow');
    elseif i == 3 || i == 6
        set(h,'marker','o','MarkerFace','blue','MarkerSize',15);
    else 
        set(h,'MarkerFace','red','MarkerSize',20);
    end
    
if i == 2 || i == 5
    set(Chuck,'visible','off');
elseif i == 3 || i == 6
    set(Blues,'visible','off');
else 
    set(Red,'visible','off')
end

for k = 1:length(polozenie_x)
        if polozenie_y(k) <= 168
            set(h,'visible','off');
            break
        elseif (polozenie_x(k)- 702)^2 + (polozenie_y(k) - 229.5)^2 <= 1225
            Ts_1_visible_value = get(Ts_1,'visible');
            switch Ts_1_visible_value 
                case 'off'
                    score_1 = score_1 + 5000;
                    set(h,'visible','off');
                    set(Ts_1,'visible','on');
                    break
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif (polozenie_x(k)- 1021.5)^2 + (polozenie_y(k) - 456)^2 <= 1225
            Ts_3_visible_value = get(Ts_3,'visible');
            switch Ts_3_visible_value 
                case 'off'
                    score_1 = score_1 + 5000;
                    set(h,'visible','off');
                    set(Ts_3,'visible','on');
                    break
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif (polozenie_x(k)- 900)^2 + (polozenie_y(k) - 196)^2 <= 1225
            Ts_2_visible_value = get(Ts_2,'visible');
            switch Ts_2_visible_value 
                case 'off'
                    score_1 = score_1 + 5000;
                    set(h,'visible','off');
                    set(Ts_2,'visible','on');
                    break
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow    
            end
        elseif polozenie_x(k) >= 666 && polozenie_x(k) <= 738 && polozenie_y(k) >= 171 && polozenie_y(k) <= 205
            switch get(HH_1,'visible');
                case 'on'
                    set(HH_1,'visible','off');
                    score_1 = score_1 + 212;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 900 && polozenie_x(k) <= 972 && polozenie_y(k) >= 242 && polozenie_y(k) <= 265
            switch get(BB_1,'visible');
                case 'on'
                    set(BB_1,'visible','off');
                    score_1 = score_1 + 141;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 828 && polozenie_x(k) <= 900 && polozenie_y(k) >= 242 && polozenie_y(k) <= 265
            switch get(BB_2,'visible');
                case 'on'
                    set(BB_2,'visible','off');
                    score_1 = score_1 + 141;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end            
        elseif polozenie_x(k) >= 828 && polozenie_x(k) <= 851 && polozenie_y(k) >= 171 && polozenie_y(k) <= 243
            switch get(CC_1,'visible');
                case 'on'
                    set(CC_1,'visible','off');
                    score_1 = score_1 + 141;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 949.5 && polozenie_x(k) <= 972.5 && polozenie_y(k) >= 171 && polozenie_y(k) <= 243
            switch get(CC_2,'visible');
                case 'on'
                    set(CC_2,'visible','off');
                    score_1 = score_1 + 141;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 949.5 && polozenie_x(k) <= 972.5 && polozenie_y(k) >= 264.5 && polozenie_y(k) <= 336.5
            switch get(CC_3,'visible');
                case 'on'
                    set(CC_3,'visible','off');
                    score_1 = score_1 + 141;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 949.5 && polozenie_x(k) <= 972.5 && polozenie_y(k) >= 336.5 && polozenie_y(k) <= 408.5
            switch get(CC_4,'visible');
                case 'on'
                    set(CC_4,'visible','off');
                    score_1 = score_1 + 141;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 949.5 && polozenie_x(k) <= 1021.5 && polozenie_y(k) >= 408.5 && polozenie_y(k) <= 431.5
            switch get(BB_3,'visible');
                case 'on'
                    set(BB_3,'visible','off');
                    score_1 = score_1 + 141;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1071 && polozenie_x(k) <= 1094 && polozenie_y(k) >= 171 && polozenie_y(k) <= 409
            switch get(DD_1,'visible');
                case 'on'
                    set(DD_1,'visible','off');
                    score_1 = score_1 + 433;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1021.5 && polozenie_x(k) <= 1093.5 && polozenie_y(k) >= 408.5 && polozenie_y(k) <= 431.5
            switch get(BB_4,'visible');
                case 'on'
                    set(BB_4,'visible','off');
                    score_1 = score_1 + 141;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1010 && polozenie_x(k) <= 1032 && polozenie_y(k) >= 171 && polozenie_y(k) <= 269
            switch get(EE_1,'visible');
                case 'on'
                    set(EE_1,'visible','off');
                    score_1 = score_1 + 179;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 937.5 && polozenie_x(k) <= 1105.5 && polozenie_y(k) >= 528 && polozenie_y(k) <= 548
            switch get(FF_1,'visible');
                case 'on'
                    set(FF_1,'visible','off');
                    score_1 = score_1 + 358;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 979.5 && polozenie_x(k) <= 1061.5 && polozenie_y(k) >= 269 && polozenie_y(k) <= 351
            switch get(II_1,'visible');
                case 'on'
                    set(II_1,'visible','off');
                    score_1 = score_1 + 496;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 883 && polozenie_x(k) <= 917 && polozenie_y(k) >= 265 && polozenie_y(k) <= 337
            switch get(GG_1,'visible');
                case 'on'
                    set(GG_1,'visible','off');
                    score_1 = score_1 + 212;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 875.5 && polozenie_x(k) <= 925.5 && polozenie_y(k) >= 335.5 && polozenie_y(k) <= 385.5
            JJ_1_visible_value = get(JJ_1,'visible');
            switch JJ_1_visible_value 
                case 'on'
                    
                    set(Exp_1,'visible','on');
                    pause(0.1);
                    set(h,'visible','off');
                    set(Exp_2,'visible','on');
                    set(Exp_1,'visible','off');
                    pause(0.1);
                    set(Exp_3,'visible','on');
                    set(Exp_2,'visible','off');
                    pause(0.1);
                    set(Exp_4,'visible','on');
                    set(Exp_3,'visible','off');
                    pause(0.1);
                    set(Exp_5,'visible','on');
                    set(Exp_4,'visible','off');
                    pause(0.1);
                    set(Exp_6,'visible','on');
                    set(Exp_5,'visible','off');
                    pause(0.1);
                    set(Exp_7,'visible','on');
                    set(Exp_6,'visible','off');
                    pause(0.1);
                    set(Ts_3,'visible','on');
                    set(JJ_1,'visible','off');
                    set(GG_1,'visible','off');
                    set(BB_1,'visible','off');
                    set(BB_2,'visible','off');
                    set(CC_3,'visible','off');
                    set(CC_4,'visible','off');
                    set(BB_3,'visible','off');
                    set(EE_2,'visible','off');
                    set(KK_1,'visible','off');
                    set(II_1,'visible','off');
                    set(Exp_8,'visible','on');
                    set(Exp_7,'visible','off');
                    pause(0.1);
                    set(Exp_9,'visible','on');
                    set(Exp_8,'visible','off');
                    pause(0.1);
                    set(Exp_10,'visible','on');
                    set(Exp_9,'visible','off');
                    pause(0.1);
                    set(Exp_11,'visible','on');
                    set(Exp_10,'visible','off');
                    pause(0.1);
                    set(Exp_12,'visible','on');
                    set(Exp_11,'visible','off');
                    pause(0.1);
                    set(Exp_13,'visible','on');
                    set(Exp_12,'visible','off');
                    pause(0.1);
                    set(Exp_14,'visible','on');
                    set(Exp_13,'visible','off');
                    pause(0.1);
                    set(Exp_15,'visible','on');
                    set(Exp_14,'visible','off');
                    pause(0.1);
                    set(Exp_15,'visible','off');
                    score_1 = score_1 + 6717;
                    break
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end    
        elseif polozenie_x(k) >= 971.5 && polozenie_x(k) <= 993.5 && polozenie_y(k) >= 431 && polozenie_y(k) <= 451
            switch get(KK_1,'visible');
                case 'on'
                    set(KK_1,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1049.5 && polozenie_x(k) <= 1071.5 && polozenie_y(k) >= 431 && polozenie_y(k) <= 451
            switch get(KK_2,'visible');
                case 'on'
                    set(KK_2,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 949.5 && polozenie_x(k) <= 971.5 && polozenie_y(k) >= 431 && polozenie_y(k) <= 529
            switch get(EE_2,'visible');
                case 'on'
                    set(EE_2,'visible','off');
                    score_1 = score_1 + 179;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1071.5 && polozenie_x(k) <= 1093.5 && polozenie_y(k) >= 431 && polozenie_y(k) <= 529
            switch get(EE_3,'visible');
                case 'on'
                    set(EE_3,'visible','off');
                    score_1 = score_1 + 179;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 937.5 && polozenie_x(k) <= 959.5 && polozenie_y(k) >= 548 && polozenie_y(k) <= 568
            switch get(KK_3,'visible');
                case 'on'
                    set(KK_3,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1083.5 && polozenie_x(k) <= 1105.5 && polozenie_y(k) >= 548 && polozenie_y(k) <= 568
            switch get(KK_4,'visible');
                case 'on'
                    set(KK_4,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 959.5 && polozenie_x(k) <= 981.5 && polozenie_y(k) >= 548 && polozenie_y(k) <= 568
            switch get(KK_5,'visible');
                case 'on'
                    set(KK_5,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1061.5 && polozenie_x(k) <= 1083.5 && polozenie_y(k) >= 548 && polozenie_y(k) <= 568
            switch get(KK_6,'visible');
                case 'on'
                    set(KK_6,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 948.5 && polozenie_x(k) <= 970.5 && polozenie_y(k) >= 568 && polozenie_y(k) <= 588
            switch get(KK_7,'visible');
                case 'on'
                    set(KK_7,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 970.5 && polozenie_x(k) <= 992.5 && polozenie_y(k) >= 568 && polozenie_y(k) <= 588
            switch get(KK_8,'visible');
                case 'on'
                    set(KK_8,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 926.5 && polozenie_x(k) <= 948.5 && polozenie_y(k) >= 568 && polozenie_y(k) <= 588
            switch get(KK_9,'visible');
                case 'on'
                    set(KK_9,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1072.5 && polozenie_x(k) <= 1094.5 && polozenie_y(k) >= 568 && polozenie_y(k) <= 588
            switch get(KK_10,'visible');
                case 'on'
                    set(KK_10,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1094.5 && polozenie_x(k) <= 1116.5 && polozenie_y(k) >= 568 && polozenie_y(k) <= 588
            switch get(KK_11,'visible');
                case 'on'
                    set(KK_11,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1050.5 && polozenie_x(k) <= 1072.5 && polozenie_y(k) >= 568 && polozenie_y(k) <= 588
            switch get(KK_12,'visible');
                case 'on'
                    set(KK_12,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 948.5 && polozenie_x(k) <= 970.5 && polozenie_y(k) >= 588 && polozenie_y(k) <= 608
            switch get(KK_13,'visible');
                case 'on'
                    set(KK_13,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 915.5 && polozenie_x(k) <= 937.5 && polozenie_y(k) >= 588 && polozenie_y(k) <= 608
            switch get(KK_14,'visible');
                case 'on'
                    set(KK_14,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 981.5 && polozenie_x(k) <= 1003.5 && polozenie_y(k) >= 588 && polozenie_y(k) <= 608
            switch get(KK_15,'visible');
                case 'on'
                    set(KK_15,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1072.5 && polozenie_x(k) <= 1094.5 && polozenie_y(k) >= 588 && polozenie_y(k) <= 608
            switch get(KK_16,'visible');
                case 'on'
                    set(KK_16,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1105.5 && polozenie_x(k) <= 1127.5 && polozenie_y(k) >= 588 && polozenie_y(k) <= 608
            switch get(KK_17,'visible');
                case 'on'
                    set(KK_17,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        elseif polozenie_x(k) >= 1039.5 && polozenie_x(k) <= 1061.5 && polozenie_y(k) >= 588 && polozenie_y(k) <= 608
            switch get(KK_18,'visible');
                case 'on'
                    set(KK_18,'visible','off');
                    score_1 = score_1 + 53;
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
                otherwise
                    set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
                    pause(t);
                    drawnow
            end
        else       
            set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
            pause(t);
            drawnow
        end
end

Ts_1_visible_value = get(Ts_1,'visible');
Ts_2_visible_value = get(Ts_2,'visible');
Ts_3_visible_value = get(Ts_3,'visible');

if i <= 6 && strcmp(Ts_1_visible_value,'on') && strcmp(Ts_2_visible_value,'on') && strcmp(Ts_3_visible_value,'on')
    score_1 = score_1 + 4800 - (800*i);
    if highscore_1 <= score_1
        highscore_1 = score_1;
    end
    set(handles.Score_1,'string',score_1);
    set(handles.Highscore_1,'string',highscore_1);
    if score_1 <= 16400
        set(Win_sc_1,'visible','on');
    elseif score_1 <= 19100
        set(Win_sc_2,'visible','on');
    else
        set(Win_sc_3,'visible','on');
    end
    set(handles.uipanel1,'visible','off');
    set(handles.text2,'visible','off');
    set(handles.text3,'visible','off');
    set(handles.edit1,'visible','off');
    set(handles.edit2,'visible','off');
    set(handles.Throw_1,'visible','off');
    set(handles.Replay_1,'visible','on');
    set(handles.Exit,'visible','on');
    set(handles.Levels,'visible','on');
    set(handles.Score_1,'visible','on');
    set(handles.Highscore,'visible','on');
    set(handles.Highscore_1,'visible','on');
    i = 0;
    lvl = 1;
elseif i >= 6 && (strcmp(Ts_1_visible_value,'off') || strcmp(Ts_2_visible_value,'off') || strcmp(Ts_3_visible_value,'off'))
    set(handles.Score_1,'string',score_1);
    i = 0;
    set(Fail_sc,'visible','on');
    set(handles.uipanel1,'visible','off');
    set(handles.text2,'visible','off');
    set(handles.text3,'visible','off');
    set(handles.edit1,'visible','off');
    set(handles.edit2,'visible','off');
    set(handles.Throw_1,'visible','off');
    set(handles.Replay_1,'visible','on');
    set(handles.Exit,'visible','on');
    set(handles.Levels,'visible','on');
else
end

% --- Executes on button press in Replay_1.
function Replay_1_Callback(~, ~, handles)
% hObject    handle to Replay_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global score_1;
score_1 = 0;

set(handles.Replay_1,'visible','off');
set(handles.Exit,'visible','off');
set(handles.Levels,'visible','off');
set(handles.Score_1,'visible','off');
set(handles.Highscore,'visible','off');
set(handles.Highscore_1,'visible','off');

global i;
global B;
global C;
global D;
global E;
global F;
global G;
global H;
global I;
global J;
global K;
global BB_1;
global BB_2;
global BB_3;
global BB_4;
global CC_1;
global CC_2;
global CC_3;
global CC_4;
global DD_1;
global EE_1;
global EE_2;
global EE_3;
global FF_1;
global GG_1;
global HH_1;
global II_1;
global JJ_1;
global KK_1;
global KK_2;
global KK_3;
global KK_4;
global KK_5;
global KK_6;
global KK_7;
global KK_8;
global KK_9;
global KK_10;
global KK_11;
global KK_12;
global KK_13;
global KK_14;
global KK_15;
global KK_16;
global KK_17;
global KK_18;
global TS_1;
global TS_2;
global TS_3;
global Ts_1;
global Ts_2;
global Ts_3;
global Ex_1;
global Ex_2;
global Ex_3;
global Ex_4;
global Ex_5;
global Ex_6;
global Ex_7;
global Ex_8;
global Ex_9;
global Ex_10;
global Ex_11;
global Ex_12;
global Ex_13;
global Ex_14;
global Ex_15;
global Exp_1;
global Exp_2;
global Exp_3;
global Exp_4;
global Exp_5;
global Exp_6;
global Exp_7;
global Exp_8;
global Exp_9;
global Exp_10;
global Exp_11;
global Exp_12;
global Exp_13;
global Exp_14;
global Exp_15;
global Fail_Sc;
global Fail_sc;
global Win_Sc_1;
global Win_Sc_2;
global Win_Sc_3;
global Win_sc_1;
global Win_sc_2;
global Win_sc_3;
global Red;
global Blues;
global Chuck;
global Redd;
global Bluess;
global Chuckk;
global level_select;
global Level_1_1;
global Level_1_2;
global Level_1_3;
global Level_1_4;
global Level_1_5;
global Level_1_6;
global Level_1_7;
global level_1_1;
global level_1_2;
global level_1_3;
global level_1_4;
global level_1_5;
global level_1_6;
global level_1_7;

set(level_select,'visible','off');
set(handles.Level_1,'visible','off');
set(handles.Level_2,'visible','off');

Level_1_1 = imread('Level_1_1.JPG');
level_1_1 = imshow(Level_1_1);
Level_1_2 = imread('Level_1_2.JPG');
level_1_2 = imshow(Level_1_2);
set(level_1_2,'visible','off');
Level_1_3 = imread('Level_1_3.JPG');
level_1_3 = imshow(Level_1_3);
set(level_1_3,'visible','off');
Level_1_4 = imread('Level_1_4.JPG');
level_1_4 = imshow(Level_1_4);
set(level_1_4,'visible','off');
Level_1_5 = imread('Level_1_5.JPG');
level_1_5 = imshow(Level_1_5);
set(level_1_5,'visible','off');
Level_1_6 = imread('Level_1_6.JPG');
level_1_6 = imshow(Level_1_6);
set(level_1_6,'visible','off');
Level_1_7 = imread('Level_1_7.JPG');
level_1_7 = imshow(Level_1_7);
set(level_1_7,'visible','off');
B = imread('Drewno_Poziom.JPG'); % 72 x 23
C = imread('Drewno_Pion.JPG'); % 23 x 72
D = imread('Drewno_Pion_Dlugie.JPG'); % 23 x 238
E = imread('Lod_Pion.JPG'); % 22 x 98
F = imread('Lod_Poziom_Dlugi.JPG'); % 168 x 20
G = imread('Kamien_Pion.JPG'); % 34 x 72
H = imread('Kamien_Poziom.JPG'); % 72 x 34
I = imread('Lodowy_Trojkat.JPG'); % 82 x 82
J = imread('TNT.JPG');  % 50 x 50
K = imread('Lodowa_Kostka.JPG'); % 22 x 20
TS_1 = imread('Tlo_Swini_1.JPG'); % 50 x 50
TS_2 = imread('Tlo_Swini_2.JPG'); % 50 x 50
TS_3 = imread('Tlo_Swini_3.JPG'); % 50 x 50
Ex_1 = imread('Explosion_1.JPG');
Ex_2 = imread('Explosion_2.JPG');
Ex_3 = imread('Explosion_3.JPG');
Ex_4 = imread('Explosion_4.JPG');
Ex_5 = imread('Explosion_5.JPG');
Ex_6 = imread('Explosion_6.JPG');
Ex_7 = imread('Explosion_7.JPG');
Ex_8 = imread('Explosion_8.JPG');
Ex_9 = imread('Explosion_9.JPG');
Ex_10 = imread('Explosion_10.JPG');
Ex_11 = imread('Explosion_11.JPG');
Ex_12 = imread('Explosion_12.JPG');
Ex_13 = imread('Explosion_13.JPG');
Ex_14 = imread('Explosion_14.JPG');
Ex_15 = imread('Explosion_15.JPG');
Redd = imread('Red.JPG');
Bluess = imread('Blues.JPG');
Chuckk = imread('Chuck.JPG');
HH_1 = imagesc(666,171,H);
BB_1 = imagesc(900,242,B);
BB_2 = imagesc(828,242,B);
CC_1 = imagesc(828,171,C);
CC_2 = imagesc(949.5,171,C);
CC_3 = imagesc(949.5,264.5,C);
CC_4 = imagesc(949.5,336.5,C);
BB_3 = imagesc(949.5,408.5,B);
DD_1 = imagesc(1071,171,D);
BB_4 = imagesc(1021.5,408.5,B);
EE_1 = imagesc(1010,171,E);
FF_1 = imagesc(937.5,528,F);
II_1 = imagesc(979.5,269,I);
GG_1 = imagesc(883,265,G);
JJ_1 = imagesc(875,335.5,J);
KK_1 = imagesc(971.5,431,K);
KK_2 = imagesc(1049.5,431,K);
EE_2 = imagesc(949.5,431,E);
EE_3 = imagesc(1071.5,431,E);
KK_3 = imagesc(937.5,548,K);
KK_4 = imagesc(1083.5,548,K);
KK_5 = imagesc(959.5,548,K);
KK_6 = imagesc(1061.5,548,K);
KK_7 = imagesc(948.5,568,K);
KK_8 = imagesc(970.5,568,K);
KK_9 = imagesc(926.5,568,K);
KK_10 = imagesc(1072.5,568,K);
KK_11 = imagesc(1094.5,568,K);
KK_12 = imagesc(1050.5,568,K);
KK_13 = imagesc(948.5,588,K);
KK_14 = imagesc(915.5,588,K);
KK_15 = imagesc(981.5,588,K);
KK_16 = imagesc(1072.5,588,K);
KK_17 = imagesc(1105.5,588,K);
KK_18 = imagesc(1039.5,588,K);
set(gca,'YDir','normal');
swinka(25,25,702,229.5);
swinka(25,25,900,196);
swinka(25,25,1021.5,456);
Ts_1 = imagesc(673,204.5,TS_1);
set(Ts_1,'visible','off');
Ts_2 = imagesc(871,171,TS_2);
set(Ts_2,'visible','off');
Ts_3 = imagesc(992.5,431,TS_3);
set(Ts_3,'visible','off');
Exp_1 = imagesc(828,243,Ex_1);
set(Exp_1,'visible','off');
Exp_2 = imagesc(828,243,Ex_2);
set(Exp_2,'visible','off');
Exp_3 = imagesc(828,243,Ex_3);
set(Exp_3,'visible','off');
Exp_4 = imagesc(828,243,Ex_4);
set(Exp_4,'visible','off');
Exp_5 = imagesc(828,243,Ex_5);
set(Exp_5,'visible','off');
Exp_6 = imagesc(828,243,Ex_6);
set(Exp_6,'visible','off');
Exp_7 = imagesc(828,243,Ex_7);
set(Exp_7,'visible','off');
Exp_8 = imagesc(827,243,Ex_8);
set(Exp_8,'visible','off');
Exp_9 = imagesc(827,243,Ex_9);
set(Exp_9,'visible','off');
Exp_10 = imagesc(827,243,Ex_10);
set(Exp_10,'visible','off');
Exp_11 = imagesc(827,243,Ex_11);
set(Exp_11,'visible','off');
Exp_12 = imagesc(827,243,Ex_12);
set(Exp_12,'visible','off');
Exp_13 = imagesc(827,243,Ex_13);
set(Exp_13,'visible','off');
Exp_14 = imagesc(827,243,Ex_14);
set(Exp_14,'visible','off');
Exp_15 = imagesc(827,243,Ex_15);
set(Exp_15,'visible','off');
Fail_Sc = imread('Fail_Screen.JPG'); % 364 x 340
Fail_sc = imagesc(400,260,Fail_Sc);
set(Fail_sc,'visible','off');
Win_Sc_1 = imread('Win_Screen_1.PNG');
Win_sc_1 = imagesc(400,260,Win_Sc_1);
set(Win_sc_1,'visible','off');
Win_Sc_2 = imread('Win_Screen_2.PNG');
Win_sc_2 = imagesc(400,260,Win_Sc_2);
set(Win_sc_2,'visible','off');
Win_Sc_3 = imread('Win_Screen_3.PNG');
Win_sc_3 = imagesc(400,260,Win_Sc_3);
set(Win_sc_3,'visible','off');
Red = imagesc(11,231,Redd);
set(Red,'visible','off');
Chuck = imagesc(11,231,Chuckk);
set(Chuck,'visible','off');
Blues = imagesc(11,231,Bluess);
set(Blues,'visible','off');
i = 0;
set(handles.Play,'visible','off');
set(handles.uipanel1,'visible','on');
set(handles.text2,'visible','on');
set(handles.text3,'visible','on');
set(handles.edit1,'visible','on');
set(handles.edit2,'visible','on');
set(handles.Throw_1,'visible','on');
set(handles.edit1,'string',0);
set(handles.edit2,'string',0);

% --- Executes on button press in Exit.
function Exit_Callback(hObject, eventdata, handles)
% hObject    handle to Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.Replay_1,'visible','off');
set(handles.Replay_2,'visible','off');
set(handles.Exit,'visible','off');
set(handles.Levels,'visible','off');
set(handles.Score_1,'visible','off');
set(handles.Highscore,'visible','off');
set(handles.Highscore_1,'visible','off');

global Fail_sc;
global Main_Menu;
global main_menu;
global lvl;
global highscore_1;
global highscore_2;

set(Fail_sc,'visible','off');
hold on
axis([0 1164 0 700]);
Main_Menu = imread('Main_Menu.JPG');
main_menu = imshow(Main_Menu);
set(handles.Play,'visible','on');
set(handles.Help,'visible','on');

% --- Executes on button press in Levels.
function Levels_Callback(~, ~, handles)
% hObject    handle to Levels (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.Replay_1,'visible','off');
set(handles.Replay_2,'visible','off');
set(handles.Exit,'visible','off');
set(handles.Levels,'visible','off');
set(handles.Score_1,'visible','off');
set(handles.Highscore,'visible','off');
set(handles.Highscore_1,'visible','off');

global Fail_sc;
global Level_Select;
global level_select;
global lvl;

set(Fail_sc,'visible','off');
hold on
axis([0 1164 0 700]);
set(gca,'YDir','normal');

if lvl == 0
    Level_Select = imread('Level_Select.JPG');
    level_select = imshow(Level_Select);
elseif lvl == 1
    Level_Select = imread('Level_Select_2.JPG');
    level_select = imshow(Level_Select);
end
set(handles.Level_1,'visible','on');
set(handles.Level_2,'visible','on');

function edit1_Callback(~, ~, ~)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, ~, ~)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(~, ~, ~)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, ~, ~)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Score_Callback(~, ~, ~)
% hObject    handle to Score_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Score_1 as text
%        str2double(get(hObject,'String')) returns contents of Score_1 as a double


% --- Executes during object creation, after setting all properties.
function Score_1_CreateFcn(hObject, ~, ~)
% hObject    handle to Score_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
push


% --- Executes on button press in Level_2.
function Level_2_Callback(~, ~, handles)
% hObject    handle to Level_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global i;
global B;
global C;
global D;
global E;
global F;
global G;
global H;
global I;
global J;
global K;
global L;
global M;
global LL_1;
global LL_2;
global LL_3;
global MM_1;
global MM_2;
global MM_3;
global MM_4;
global JJ_2;
global JJ_3;
global JJ_4;
global JJ_5;
global JJ_6;
global JJ_7;
global JJ_8;
global JJ_9;
global JJ_10;
global JJ_11;
global JJ_12;
global JJ_13;
global JJ_14;
global JJ_15;
global JJ_16;
global JJ_17;
global JJ_18;
global JJ_19;
global C4;
global C4_1;
global C4_2;
global Fail_Sc;
global Fail_sc;
global Win_Sc_1;
global Win_Sc_2;
global Win_Sc_3;
global Win_sc_1;
global Win_sc_2;
global Win_sc_3;
global Red;
global Blues;
global Chuck;
global Redd;
global Bluess;
global Chuckk;
global level_select;
global score_2;
global BOOM_1;
global BOOM_2;
global BOOM_3;
global BOOM_4;
global BOOM_5;
global BOOM_6;
global BOOM_7;
global BOOM_8;
global BOOM_9;
global BOOM_10;
global BOOM_11;
global BOOM_12;
global BOOM_13;
global BOOM_14;
global BOOM_15;
global BOOM_16;
global BOOM_17;
global BOOM_18;
global BOOM_19;
global BOOM_20;
global BOOM_21;
global BOOM_22;
global boom_1;
global boom_2;
global boom_3;
global boom_4;
global boom_5;
global boom_6;
global boom_7;
global boom_8;
global boom_9;
global boom_10;
global boom_11;
global boom_12;
global boom_13;
global boom_14;
global boom_15;
global boom_16;
global boom_17;
global boom_18;
global boom_19;
global boom_20;
global boom_21;
global boom_22;
global Level_2_1;
global Level_2_2;
global Level_2_3;
global Level_2_4;
global Level_2_5;
global level_2_1;
global level_2_2;
global level_2_3;
global level_2_4;
global level_2_5;

score_2 = 0;
set(level_select,'visible','off');
set(handles.Level_1,'visible','off');
set(handles.Level_2,'visible','off');

Level_2_1 = imread('Level_2_1.JPG');
level_2_1 = imshow(Level_2_1);
Level_2_2 = imread('Level_2_2.JPG');
level_2_2 = imshow(Level_2_2);
set(level_2_2,'visible','off');
Level_2_3 = imread('Level_2_3.JPG');
level_2_3 = imshow(Level_2_3);
set(level_2_3,'visible','off');
Level_2_4 = imread('Level_2_4.JPG');
level_2_4 = imshow(Level_2_4);
set(level_2_4,'visible','off');
Level_2_5 = imread('Level_2_5.JPG');
level_2_5 = imshow(Level_2_5);
set(level_2_5,'visible','off');
B = imread('Drewno_Poziom.JPG'); % 72 x 23
C = imread('Drewno_Pion.JPG'); % 23 x 72
D = imread('Drewno_Pion_Dlugie.JPG'); % 23 x 238
E = imread('Lod_Pion.JPG'); % 22 x 98
F = imread('Lod_Poziom_Dlugi.JPG'); % 168 x 20
G = imread('Kamien_Pion.JPG'); % 34 x 72
H = imread('Kamien_Poziom.JPG'); % 72 x 34
I = imread('Lodowy_Trojkat.JPG'); % 82 x 82
J = imread('TNT.JPG');  % 50 x 50
K = imread('Lodowa_Kostka.JPG'); % 22 x 20
L = imread('Kamien_Poziom_Dlugi.JPG'); % 200 x 20
M = imread('Kamien_Pion_Dlugi.JPG'); % 20 x 200
C4 = imread('C4.JPG'); % 30 x 50
Redd = imread('Red.JPG');
Bluess = imread('Blues.JPG');
Chuckk = imread('Chuck.JPG');
set(gca,'YDir','normal');
LL_1 = imagesc(430,370,L);
LL_2 = imagesc(600,370,L);
LL_3 = imagesc(770,370,L);
MM_1 = imagesc(430,170,M);
JJ_2 = imagesc(450,170,J);
JJ_14 = imagesc(450,220,J);
JJ_15 = imagesc(450,270,J);
JJ_16 = imagesc(450,320,J);
MM_2 = imagesc(500,170,M);
JJ_3 = imagesc(520,170,J);
JJ_4 = imagesc(570,170,J);
JJ_5 = imagesc(520,220,J);
JJ_6 = imagesc(570,220,J);
JJ_7 = imagesc(520,270,J);
JJ_8 = imagesc(780,170,J);
JJ_9 = imagesc(830,170,J);
JJ_10 = imagesc(780,220,J);
JJ_11 = imagesc(830,220,J);
JJ_12 = imagesc(830,270,J);
MM_3 = imagesc(880,170,M);
JJ_13 = imagesc(900,170,J);
JJ_17 = imagesc(900,220,J);
JJ_18 = imagesc(900,270,J);
JJ_19 = imagesc(900,320,J);
MM_4 = imagesc(950,170,M);
C4_1 = imagesc(495,265,C4);
C4_2 = imagesc(875,265,C4);
swinka(80,80,700,250);
BOOM_1 = imread('Boom_1.JPG');
boom_1 = imshow(BOOM_1);
set(boom_1,'visible','off');
BOOM_2 = imread('Boom_2.JPG');
boom_2 = imshow(BOOM_2);
set(boom_2,'visible','off');
BOOM_3 = imread('Boom_3.JPG');
boom_3 = imshow(BOOM_3);
set(boom_3,'visible','off');
BOOM_4 = imread('Boom_4.JPG');
boom_4 = imshow(BOOM_4);
set(boom_4,'visible','off');
BOOM_5 = imread('Boom_5.JPG');
boom_5 = imshow(BOOM_5);
set(boom_5,'visible','off');
BOOM_6 = imread('Boom_6.JPG');
boom_6 = imshow(BOOM_6);
set(boom_6,'visible','off');
BOOM_7 = imread('Boom_7.JPG');
boom_7 = imshow(BOOM_7);
set(boom_7,'visible','off');
BOOM_8 = imread('Boom_8.JPG');
boom_8 = imshow(BOOM_8);
set(boom_8,'visible','off');
BOOM_9 = imread('Boom_9.JPG');
boom_9 = imshow(BOOM_9);
set(boom_9,'visible','off');
BOOM_10 = imread('Boom_10.JPG');
boom_10 = imshow(BOOM_10);
set(boom_10,'visible','off');
BOOM_11 = imread('Boom_11.JPG');
boom_11 = imshow(BOOM_11);
set(boom_11,'visible','off');
BOOM_12 = imread('Boom_12.JPG');
boom_12 = imshow(BOOM_12);
set(boom_12,'visible','off');
BOOM_13 = imread('Boom_13.JPG');
boom_13 = imshow(BOOM_13);
set(boom_13,'visible','off');
BOOM_14 = imread('Boom_14.JPG');
boom_14 = imshow(BOOM_14);
set(boom_14,'visible','off');
BOOM_15 = imread('Boom_15.JPG');
boom_15 = imshow(BOOM_15);
set(boom_15,'visible','off');
BOOM_16 = imread('Boom_16.JPG');
boom_16 = imshow(BOOM_16);
set(boom_16,'visible','off');
BOOM_17 = imread('Boom_17.JPG');
boom_17 = imshow(BOOM_17);
set(boom_17,'visible','off');
BOOM_18 = imread('Boom_18.JPG');
boom_18 = imshow(BOOM_18);
set(boom_18,'visible','off');
BOOM_19 = imread('Boom_19.JPG');
boom_19 = imshow(BOOM_19);
set(boom_19,'visible','off');
BOOM_20 = imread('Boom_20.JPG');
boom_20 = imshow(BOOM_20);
set(boom_20,'visible','off');
BOOM_21 = imread('Boom_21.JPG');
boom_21 = imshow(BOOM_21);
set(boom_21,'visible','off');
BOOM_22 = imread('Boom_22.JPG');
boom_22 = imshow(BOOM_22);
set(boom_22,'visible','off');
set(gca,'YDir','normal');
Fail_Sc = imread('Fail_Screen.JPG'); % 364 x 340
Fail_sc = imagesc(400,260,Fail_Sc);
set(Fail_sc,'visible','off');
Win_Sc_1 = imread('Win_Screen_1.PNG');
Win_sc_1 = imagesc(400,260,Win_Sc_1);
set(Win_sc_1,'visible','off');
Win_Sc_2 = imread('Win_Screen_2.PNG');
Win_sc_2 = imagesc(400,260,Win_Sc_2);
set(Win_sc_2,'visible','off');
Win_Sc_3 = imread('Win_Screen_3.PNG');
Win_sc_3 = imagesc(400,260,Win_Sc_3);
set(Win_sc_3,'visible','off');
Red = imagesc(11,231,Redd);
set(Red,'visible','off');
Chuck = imagesc(11,231,Chuckk);
set(Chuck,'visible','off');
Blues = imagesc(11,231,Bluess);
set(Blues,'visible','off');
i = 0;
set(handles.Play,'visible','off');
set(handles.uipanel1,'visible','on');
set(handles.text2,'visible','on');
set(handles.text3,'visible','on');
set(handles.edit1,'visible','on');
set(handles.edit2,'visible','on');
set(handles.Throw_2,'visible','on');
set(handles.edit1,'string',0);
set(handles.edit2,'string',0);


% --- Executes on button press in Throw_2.
function Throw_2_Callback(~, ~, handles)
% hObject    handle to Throw_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global highscore_2;
global score_2;
global i;
global Fail_sc;
global Red;
global Blues;
global Chuck;
global Win_sc_1;
global Win_sc_2;
global Win_sc_3;
global lvl;
global boom_1;
global boom_2;
global boom_3;
global boom_4;
global boom_5;
global boom_6;
global boom_7;
global boom_8;
global boom_9;
global boom_10;
global boom_11;
global boom_12;
global boom_13;
global boom_14;
global boom_15;
global boom_16;
global boom_17;
global boom_18;
global boom_19;
global boom_20;
global boom_21;
global boom_22;
global level_2_2;
global level_2_3;
global level_2_4;
global level_2_5;

i = i + 1;

if i == 1
    set(level_2_2,'visible','on');
elseif i == 2
    set(level_2_3,'visible','on');
    set(level_2_2,'visible','off');
elseif i == 3 
    set(level_2_4,'visible','on');
    set(level_2_3,'visible','off');
elseif i == 4
    set(level_2_5,'visible','on');
    set(level_2_4,'visible','off');
end

if i == 2
    set(Chuck,'visible','on');
elseif i == 3
    set(Blues,'visible','on');
else 
    set(Red,'visible','on');
end

[X,Y] = ginput(1);
    
if X < 26
    z = [0 26 0;Y 252 Y-252];
elseif X <= 506
    z = [X 26 X-26;Y 252 Y-252];
else
    z = [506 26 480;Y 252 Y-252];
end

Z = sqrt((z(1,3)^2)+(z(2,3)^2));
  
if X < 26
    return
elseif z(2,3) < 0
    return
else
    if z(2,3)/Z == 1
        a = 90;
    elseif z(2,3)/Z >= 0.9996
        a = 89;
    elseif z(2,3)/Z >= 0.9990
        a = 88;
    elseif z(2,3)/Z >= 0.9981
        a = 87;
    elseif z(2,3)/Z >= 0.9969
        a = 86;
    elseif z(2,3)/Z >= 0.99535
        a = 85;
    elseif z(2,3)/Z >= 0.9935
        a = 84;
    elseif z(2,3)/Z >= 0.9914
        a = 83;
    elseif z(2,3)/Z >= 0.9890
        a = 82;
    elseif z(2,3)/Z >= 0.98625
        a = 81;
    elseif z(2,3)/Z >= 0.9832
        a = 80;
    elseif z(2,3)/Z >= 0.97985
        a = 79;
    elseif z(2,3)/Z >= 0.97625
        a = 78;
    elseif z(2,3)/Z >= 0.97235
        a = 77;
    elseif z(2,3)/Z >= 0.9681
        a = 76;
    elseif z(2,3)/Z >= 0.9636
        a = 75;
    elseif z(2,3)/Z >= 0.9588	
        a = 74;
    elseif z(2,3)/Z >= 0.9537	
        a = 73;
    elseif z(2,3)/Z >= 0.9483	
        a = 72;
    elseif z(2,3)/Z >= 0.9426	
        a = 71;
    elseif z(2,3)/Z >= 0.93665	
        a = 70;
    elseif z(2,3)/Z >= 0.9304	
        a = 69;
    elseif z(2,3)/Z >= 0.92385	
        a = 68;
    elseif z(2,3)/Z >= 0.917	
        a = 67;
    elseif z(2,3)/Z >= 0.9099	
        a = 66;
    elseif z(2,3)/Z >= 0.90255	
        a = 65;
    elseif z(2,3)/Z >= 0.8949	
        a = 64;
    elseif z(2,3)/Z >= 0.88695	
        a = 63;
    elseif z(2,3)/Z >= 0.87875	
        a = 62;
    elseif z(2,3)/Z >= 0.8703	
        a = 61;
    elseif z(2,3)/Z >= 0.8616	
        a = 60;
    elseif z(2,3)/Z >= 0.8526	
        a = 59;
    elseif z(2,3)/Z >= 0.84335	
        a = 58;
    elseif z(2,3)/Z >= 0.83385	
        a = 57;
    elseif z(2,3)/Z >= 0.8241	
        a = 56;
    elseif z(2,3)/Z >= 0.8141	
        a = 55;
    elseif z(2,3)/Z >= 0.8038	
        a = 54;
    elseif z(2,3)/Z >= 0.7933	
        a = 53;
    elseif z(2,3)/Z >= 0.78255	
        a = 52;
    elseif z(2,3)/Z >= 0.77155	
        a = 51;
    elseif z(2,3)/Z >= 0.76035	
        a = 50;
    elseif z(2,3)/Z >= 0.7489	
        a = 49;
    elseif z(2,3)/Z >= 0.73725	
        a = 48;
    elseif z(2,3)/Z >= 0.72535
        a = 47;
    elseif z(2,3)/Z >= 0.7132	
        a = 46;
    elseif z(2,3)/Z >= 0.7009
        a = 45;
    elseif z(2,3)/Z >= 0.68835
        a = 44;
    elseif z(2,3)/Z >= 0.67555
        a = 43;
    elseif z(2,3)/Z >= 0.6626
        a = 42;
    elseif z(2,3)/Z >= 0.64945
        a = 41;
    elseif z(2,3)/Z >= 0.63605
        a = 40;
    elseif z(2,3)/Z >= 0.6225
        a = 39;
    elseif z(2,3)/Z >= 0.60875
        a = 38;
    elseif z(2,3)/Z >= 0.5948
        a = 37;
    elseif z(2,3)/Z >= 0.5807
        a = 36;
    elseif z(2,3)/Z >= 0.5664
        a = 35;
    elseif z(2,3)/Z >= 0.5519
        a = 34;
    elseif z(2,3)/Z >= 0.53725
        a = 33;
    elseif z(2,3)/Z >= 0.52245
        a = 32;
    elseif z(2,3)/Z >= 0.5075
        a = 31;
    elseif z(2,3)/Z >= 0.4924
        a = 30;
    elseif z(2,3)/Z >= 0.47715
        a = 29;
    elseif z(2,3)/Z >= 0.46175
        a = 28;
    elseif z(2,3)/Z >= 0.4462
        a = 27;
    elseif z(2,3)/Z >= 0.4305
        a = 26;
    elseif z(2,3)/Z >= 0.41465
        a = 25;
    elseif z(2,3)/Z >= 0.3987
        a = 24;
    elseif z(2,3)/Z >= 0.38265
        a = 23;
    elseif z(2,3)/Z >= 0.3665
        a = 22;
    elseif z(2,3)/Z >= 0.3502
        a = 21;
    elseif z(2,3)/Z >= 0.3338
        a = 20;
    elseif z(2,3)/Z >= 0.3173
        a = 19;
    elseif z(2,3)/Z >= 0.3007
        a = 18;
    elseif z(2,3)/Z >= 0.284
        a = 17;
    elseif z(2,3)/Z >= 0.2672
        a = 16;
    elseif z(2,3)/Z >= 0.25035
        a = 15;
    elseif z(2,3)/Z >= 0.23345
        a = 14;
    elseif z(2,3)/Z >= 0.21645
        a = 13;
    elseif z(2,3)/Z >= 0.19935
        a = 12;
    elseif z(2,3)/Z >= 0.1822
        a = 11;
    elseif z(2,3)/Z >= 0.165
        a = 10;
    elseif z(2,3)/Z >= 0.1478
        a = 9;
    elseif z(2,3)/Z >= 0.13055
        a = 8;
    elseif z(2,3)/Z >= 0.1132
        a = 7;
    elseif z(2,3)/Z >= 0.09585
        a = 6;
    elseif z(2,3)/Z >= 0.0785
        a = 5;
    elseif z(2,3)/Z >= 0.06105
        a = 4;
    elseif z(2,3)/Z >= 0.0436
        a = 3;
    elseif z(2,3)/Z >= 0.0262
        a = 2;
    elseif z(2,3)/Z >= 0.00875
        a = 1;
    elseif z(2,3)/Z >= 0
        a = 0;
    end
end
    
    set(handles.edit1,'string',z(1,3)/4);
    set(handles.edit2,'string',a);
    
    V0 = str2num(get(handles.edit1,'string'));
    rad = str2num(get(handles.edit2,'string'));
    
    alfa = rad*pi/180;
    g = 9.81;
    h0 = 252;
        
    V0y = @(alfa) V0*sin(alfa);
    predkosc_poczatkowa_y = V0y(alfa);
    
    V0x = @(alfa) V0*cos(alfa);
    predkosc_poczatkowa_x = V0x(alfa);
    
    hw = (predkosc_poczatkowa_y^2)/(2*g);
    hs = h0+hw; 
    
    tw = predkosc_poczatkowa_y/g;
    ts = (((2*h0)/g)+((predkosc_poczatkowa_y^2)/(g^2)))^(1/2);
    tr = tw+ts;
    t = linspace(0,tr);
    
    Vy = @(t) predkosc_poczatkowa_y-g.*t;
    predkosc_y = Vy(t);
    
    x = @(t) predkosc_poczatkowa_x.*t+26;
    polozenie_x = x(t);
    
    y = @(t) (predkosc_poczatkowa_y.*t-((g*(t.^2))/2))+h0;
    polozenie_y = y(t);
    
    h = line('color','k','marker','o','Erase','xor','MarkerFace','red','MarkerSize',20);
    
    if i == 2 
        set(h,'marker','^','MarkerFace','yellow');
    elseif i == 3
        set(h,'marker','o','MarkerFace','blue','MarkerSize',15);
    else 
        set(h,'MarkerFace','red','MarkerSize',20);
    end
    
if i == 2
    set(Chuck,'visible','off');
elseif i == 3
    set(Blues,'visible','off');
else 
    set(Red,'visible','off')
end

for k = 1:length(polozenie_x)
        if polozenie_y(k) <= 168
            set(h,'visible','off');
            break
        elseif polozenie_x(k) >= 430 && polozenie_x(k) <= 970 && polozenie_y(k) >= 168 && polozenie_y(k) <= 390
            set(h,'visible','off');
            break
        elseif polozenie_x(k) >= 1094 && polozenie_x(k) <= 1156 && polozenie_y(k) >= 168 && polozenie_y(k) <= 296
            set(h,'visible','off');
            break
        elseif polozenie_x(k) >= 1102 && polozenie_x(k) <= 1148 && polozenie_y(k) >= 296 && polozenie_y(k) <= 313
            score_2 = score_2 + 100000;
            set(h,'visible','off');
            set(boom_1,'visible','on');
            pause(0.15);
            set(boom_2,'visible','on');
            set(boom_1,'visible','off');
            pause(0.15);
            set(boom_3,'visible','on');
            set(boom_2,'visible','off');
            pause(0.15);
            set(boom_4,'visible','on');
            set(boom_3,'visible','off');
            pause(0.15);
            set(boom_5,'visible','on');
            set(boom_4,'visible','off');
            pause(0.15);
            set(boom_6,'visible','on');
            set(boom_5,'visible','off');
            pause(0.15);
            set(boom_7,'visible','on');
            set(boom_6,'visible','off');
            pause(0.15);
            set(boom_8,'visible','on');
            set(boom_7,'visible','off');
            pause(0.15);
            set(boom_9,'visible','on');
            set(boom_8,'visible','off');
            pause(0.15);
            set(boom_10,'visible','on');
            set(boom_9,'visible','off');
            pause(0.15);
            set(boom_11,'visible','on');
            set(boom_10,'visible','off');
            pause(0.15);
            set(boom_12,'visible','on');
            set(boom_11,'visible','off');
            pause(0.15);
            set(boom_13,'visible','on');
            set(boom_12,'visible','off');
            pause(0.15);
            set(boom_14,'visible','on');
            set(boom_13,'visible','off');
            pause(0.15);
            set(boom_15,'visible','on');
            set(boom_14,'visible','off');
            pause(0.15);
            set(boom_16,'visible','on');
            set(boom_15,'visible','off');
            pause(0.15);
            set(boom_17,'visible','on');
            set(boom_16,'visible','off');
            pause(0.15);
            set(boom_18,'visible','on');
            set(boom_17,'visible','off');
            pause(0.15);
            set(boom_19,'visible','on');
            set(boom_18,'visible','off');
            pause(0.15);
            set(boom_20,'visible','on');
            set(boom_19,'visible','off');
            pause(0.15);
            set(boom_21,'visible','on');
            set(boom_20,'visible','off');
            pause(0.15);
            set(boom_22,'visible','on');
            set(boom_21,'visible','off');
            pause(0.15);
            break
        else    
            set(h,'XData',polozenie_x(k),'YData',polozenie_y(k))
            pause(t);
            drawnow
        end
end

boom_22_visible_value = get(boom_22,'visible');

if i <= 4 && strcmp(boom_22_visible_value,'on')
    score_2 = score_2 + 3200 - (800*i);
    if highscore_2 <= score_2
        highscore_2 = score_2;
    end
    set(handles.Score_1,'string',score_2);
    set(handles.Highscore_1,'string',highscore_2);
    if score_2 <= 100000
        set(Win_sc_1,'visible','on');
    elseif score_2 <= 101600
        set(Win_sc_2,'visible','on');
    else
        set(Win_sc_3,'visible','on');
    end
    set(handles.uipanel1,'visible','off');
    set(handles.text2,'visible','off');
    set(handles.text3,'visible','off');
    set(handles.edit1,'visible','off');
    set(handles.edit2,'visible','off');
    set(handles.Throw_2,'visible','off');
    set(handles.Replay_2,'visible','on');
    set(handles.Exit,'visible','on');
    set(handles.Levels,'visible','on');
    set(handles.Score_1,'visible','on');
    set(handles.Highscore,'visible','on');
    set(handles.Highscore_1,'visible','on');
    i = 0;
    lvl = 1;
elseif i == 4 && strcmp(boom_22_visible_value,'off')
    set(handles.Score_1,'string',score_2);
    i = 0;
    set(Fail_sc,'visible','on');
    set(handles.uipanel1,'visible','off');
    set(handles.text2,'visible','off');
    set(handles.text3,'visible','off');
    set(handles.edit1,'visible','off');
    set(handles.edit2,'visible','off');
    set(handles.Throw_2,'visible','off');
    set(handles.Replay_2,'visible','on');
    set(handles.Exit,'visible','on');
    set(handles.Levels,'visible','on');
else
end


% --- Executes on button press in Replay_2.
function Replay_2_Callback(~, ~, handles)
% hObject    handle to Replay_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global score_2;
score_2 = 0;

set(handles.Replay_2,'visible','off');
set(handles.Exit,'visible','off');
set(handles.Levels,'visible','off');
set(handles.Score_1,'visible','off');
set(handles.Highscore,'visible','off');
set(handles.Highscore_1,'visible','off');

global i;
global B;
global C;
global D;
global E;
global F;
global G;
global H;
global I;
global J;
global K;
global L;
global M;
global LL_1;
global LL_2;
global LL_3;
global MM_1;
global MM_2;
global MM_3;
global MM_4;
global JJ_2;
global JJ_3;
global JJ_4;
global JJ_5;
global JJ_6;
global JJ_7;
global JJ_8;
global JJ_9;
global JJ_10;
global JJ_11;
global JJ_12;
global JJ_13;
global JJ_14;
global JJ_15;
global JJ_16;
global JJ_17;
global JJ_18;
global JJ_19;
global C4;
global C4_1;
global C4_2;
global Fail_Sc;
global Fail_sc;
global Win_Sc_1;
global Win_Sc_2;
global Win_Sc_3;
global Win_sc_1;
global Win_sc_2;
global Win_sc_3;
global Red;
global Blues;
global Chuck;
global Redd;
global Bluess;
global Chuckk;
global level_select;
global BOOM_1;
global BOOM_2;
global BOOM_3;
global BOOM_4;
global BOOM_5;
global BOOM_6;
global BOOM_7;
global BOOM_8;
global BOOM_9;
global BOOM_10;
global BOOM_11;
global BOOM_12;
global BOOM_13;
global BOOM_14;
global BOOM_15;
global BOOM_16;
global BOOM_17;
global BOOM_18;
global BOOM_19;
global BOOM_20;
global BOOM_21;
global BOOM_22;
global boom_1;
global boom_2;
global boom_3;
global boom_4;
global boom_5;
global boom_6;
global boom_7;
global boom_8;
global boom_9;
global boom_10;
global boom_11;
global boom_12;
global boom_13;
global boom_14;
global boom_15;
global boom_16;
global boom_17;
global boom_18;
global boom_19;
global boom_20;
global boom_21;
global boom_22;
global Level_2_1;
global Level_2_2;
global Level_2_3;
global Level_2_4;
global Level_2_5;
global level_2_1;
global level_2_2;
global level_2_3;
global level_2_4;
global level_2_5;

set(level_select,'visible','off');
set(handles.Level_1,'visible','off');
set(handles.Level_2,'visible','off');

Level_2_1 = imread('Level_2_1.JPG');
level_2_1 = imshow(Level_2_1);
Level_2_2 = imread('Level_2_2.JPG');
level_2_2 = imshow(Level_2_2);
set(level_2_2,'visible','off');
Level_2_3 = imread('Level_2_3.JPG');
level_2_3 = imshow(Level_2_3);
set(level_2_3,'visible','off');
Level_2_4 = imread('Level_2_4.JPG');
level_2_4 = imshow(Level_2_4);
set(level_2_4,'visible','off');
Level_2_5 = imread('Level_2_5.JPG');
level_2_5 = imshow(Level_2_5);
set(level_2_5,'visible','off');
B = imread('Drewno_Poziom.JPG'); % 72 x 23
C = imread('Drewno_Pion.JPG'); % 23 x 72
D = imread('Drewno_Pion_Dlugie.JPG'); % 23 x 238
E = imread('Lod_Pion.JPG'); % 22 x 98
F = imread('Lod_Poziom_Dlugi.JPG'); % 168 x 20
G = imread('Kamien_Pion.JPG'); % 34 x 72
H = imread('Kamien_Poziom.JPG'); % 72 x 34
I = imread('Lodowy_Trojkat.JPG'); % 82 x 82
J = imread('TNT.JPG');  % 50 x 50
K = imread('Lodowa_Kostka.JPG'); % 22 x 20
L = imread('Kamien_Poziom_Dlugi.JPG'); % 200 x 20
M = imread('Kamien_Pion_Dlugi.JPG'); % 20 x 200
C4 = imread('C4.JPG'); % 30 x 50
Redd = imread('Red.JPG');
Bluess = imread('Blues.JPG');
Chuckk = imread('Chuck.JPG');
set(gca,'YDir','normal');
LL_1 = imagesc(430,370,L);
LL_2 = imagesc(600,370,L);
LL_3 = imagesc(770,370,L);
MM_1 = imagesc(430,170,M);
JJ_2 = imagesc(450,170,J);
JJ_14 = imagesc(450,220,J);
JJ_15 = imagesc(450,270,J);
JJ_16 = imagesc(450,320,J);
MM_2 = imagesc(500,170,M);
JJ_3 = imagesc(520,170,J);
JJ_4 = imagesc(570,170,J);
JJ_5 = imagesc(520,220,J);
JJ_6 = imagesc(570,220,J);
JJ_7 = imagesc(520,270,J);
JJ_8 = imagesc(780,170,J);
JJ_9 = imagesc(830,170,J);
JJ_10 = imagesc(780,220,J);
JJ_11 = imagesc(830,220,J);
JJ_12 = imagesc(830,270,J);
MM_3 = imagesc(880,170,M);
JJ_13 = imagesc(900,170,J);
JJ_17 = imagesc(900,220,J);
JJ_18 = imagesc(900,270,J);
JJ_19 = imagesc(900,320,J);
MM_4 = imagesc(950,170,M);
C4_1 = imagesc(495,265,C4);
C4_2 = imagesc(875,265,C4);
swinka(80,80,700,250);
BOOM_1 = imread('Boom_1.JPG');
boom_1 = imshow(BOOM_1);
set(boom_1,'visible','off');
BOOM_2 = imread('Boom_2.JPG');
boom_2 = imshow(BOOM_2);
set(boom_2,'visible','off');
BOOM_3 = imread('Boom_3.JPG');
boom_3 = imshow(BOOM_3);
set(boom_3,'visible','off');
BOOM_4 = imread('Boom_4.JPG');
boom_4 = imshow(BOOM_4);
set(boom_4,'visible','off');
BOOM_5 = imread('Boom_5.JPG');
boom_5 = imshow(BOOM_5);
set(boom_5,'visible','off');
BOOM_6 = imread('Boom_6.JPG');
boom_6 = imshow(BOOM_6);
set(boom_6,'visible','off');
BOOM_7 = imread('Boom_7.JPG');
boom_7 = imshow(BOOM_7);
set(boom_7,'visible','off');
BOOM_8 = imread('Boom_8.JPG');
boom_8 = imshow(BOOM_8);
set(boom_8,'visible','off');
BOOM_9 = imread('Boom_9.JPG');
boom_9 = imshow(BOOM_9);
set(boom_9,'visible','off');
BOOM_10 = imread('Boom_10.JPG');
boom_10 = imshow(BOOM_10);
set(boom_10,'visible','off');
BOOM_11 = imread('Boom_11.JPG');
boom_11 = imshow(BOOM_11);
set(boom_11,'visible','off');
BOOM_12 = imread('Boom_12.JPG');
boom_12 = imshow(BOOM_12);
set(boom_12,'visible','off');
BOOM_13 = imread('Boom_13.JPG');
boom_13 = imshow(BOOM_13);
set(boom_13,'visible','off');
BOOM_14 = imread('Boom_14.JPG');
boom_14 = imshow(BOOM_14);
set(boom_14,'visible','off');
BOOM_15 = imread('Boom_15.JPG');
boom_15 = imshow(BOOM_15);
set(boom_15,'visible','off');
BOOM_16 = imread('Boom_16.JPG');
boom_16 = imshow(BOOM_16);
set(boom_16,'visible','off');
BOOM_17 = imread('Boom_17.JPG');
boom_17 = imshow(BOOM_17);
set(boom_17,'visible','off');
BOOM_18 = imread('Boom_18.JPG');
boom_18 = imshow(BOOM_18);
set(boom_18,'visible','off');
BOOM_19 = imread('Boom_19.JPG');
boom_19 = imshow(BOOM_19);
set(boom_19,'visible','off');
BOOM_20 = imread('Boom_20.JPG');
boom_20 = imshow(BOOM_20);
set(boom_20,'visible','off');
BOOM_21 = imread('Boom_21.JPG');
boom_21 = imshow(BOOM_21);
set(boom_21,'visible','off');
BOOM_22 = imread('Boom_22.JPG');
boom_22 = imshow(BOOM_22);
set(boom_22,'visible','off');
set(gca,'YDir','normal');
Fail_Sc = imread('Fail_Screen.JPG'); % 364 x 340
Fail_sc = imagesc(400,260,Fail_Sc);
set(Fail_sc,'visible','off');
Win_Sc_1 = imread('Win_Screen_1.PNG');
Win_sc_1 = imagesc(400,260,Win_Sc_1);
set(Win_sc_1,'visible','off');
Win_Sc_2 = imread('Win_Screen_2.PNG');
Win_sc_2 = imagesc(400,260,Win_Sc_2);
set(Win_sc_2,'visible','off');
Win_Sc_3 = imread('Win_Screen_3.PNG');
Win_sc_3 = imagesc(400,260,Win_Sc_3);
set(Win_sc_3,'visible','off');
Red = imagesc(11,231,Redd);
set(Red,'visible','off');
Chuck = imagesc(11,231,Chuckk);
set(Chuck,'visible','off');
Blues = imagesc(11,231,Bluess);
set(Blues,'visible','off');
i = 0;
set(handles.Play,'visible','off');
set(handles.uipanel1,'visible','on');
set(handles.text2,'visible','on');
set(handles.text3,'visible','on');
set(handles.edit1,'visible','on');
set(handles.edit2,'visible','on');
set(handles.Throw_2,'visible','on');
set(handles.edit1,'string',0);
set(handles.edit2,'string',0);


% --- Executes during object creation, after setting all properties.
function Highscore_1_CreateFcn(~, ~, ~)
% hObject    handle to Highscore_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



% --- Executes during object creation, after setting all properties.
function Highscore_CreateFcn(~, ~, ~)
% hObject    handle to Highscore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

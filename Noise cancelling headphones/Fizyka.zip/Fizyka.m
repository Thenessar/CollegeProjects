function varargout = Fizyka(varargin)
% FIZYKA MATLAB code for Fizyka.fig
%      FIZYKA, by itself, creates a new FIZYKA or raises the existing
%      singleton*.
%
%      H = FIZYKA returns the handle to a new FIZYKA or the handle to
%      the existing singleton*.
%
%      FIZYKA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FIZYKA.M with the given input arguments.
%
%      FIZYKA('Property','Value',...) creates a new FIZYKA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Fizyka_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Fizyka_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Fizyka

% Last Modified by GUIDE v2.5 05-Jun-2016 17:02:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Fizyka_OpeningFcn, ...
                   'gui_OutputFcn',  @Fizyka_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Fizyka is made visible.
function Fizyka_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Fizyka (see VARARGIN)

% Choose default command line output for Fizyka
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Fizyka wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Fizyka_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Nagraj.
function Nagraj_Callback(hObject, eventdata, handles)
% hObject    handle to Nagraj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global X;
global Y;
global Hz;
global t;

Hz = 44100;

X = audiorecorder(Hz,16,1,2);
recordblocking(X,5);
Y = getaudiodata(X);
t = 0:1/Hz:length(Y)/Hz - 1/Hz;
axes(handles.axes3);
plot(t,Y);
axis([0 5 -0.5 0.5]);

% --- Executes on button press in Rysuj1.
function Rysuj1_Callback(hObject, eventdata, handles)
% hObject    handle to Rysuj1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global X;
global Y;
global Hz;
global t;

Y = getaudiodata(X);
t = 0:1/Hz:length(Y)/Hz - 1/Hz;
axes(handles.axes3);
plot(t,Y,'b');
axis([0 5 -0.5 0.5]);
% --- Executes on button press in Rysuj2.
function Rysuj2_Callback(hObject, eventdata, handles)
% hObject    handle to Rysuj2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Y;
global X;
global t;
global Hz;
global Z;

Y = getaudiodata(X);
t = 0:1/Hz:length(Y)/Hz - 1/Hz;
Z = -Y;
axes(handles.axes4);
plot(t,Z,'r');
axis([0 5 -0.5 0.5]);
% --- Executes on button press in Rysuj3.
function Rysuj3_Callback(hObject, eventdata, handles)
% hObject    handle to Rysuj3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global X;
global Y;
global Hz;
global t;
global Z;
global A;

A = Z;
A(44100*1:44100*3,1) = 0;
Y = getaudiodata(X);
t = 0:1/Hz:length(Y)/Hz - 1/Hz;
axes(handles.axes5);
plot(t,A+Y,'g');
axis([0 5 -0.5 0.5]);

% --- Executes on button press in Rysuj4.
function Rysuj4_Callback(hObject, eventdata, handles)
% hObject    handle to Rysuj4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Y;
global t;

axes(handles.axes6);
plot(t,Y);
axis([0 5 -0.5 0.5]);

% --- Executes on button press in Odtworz1.
function Odtworz1_Callback(hObject, eventdata, handles)
% hObject    handle to Odtworz1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Y;
global Hz;

sound(Y,Hz);

% --- Executes on button press in Odtworz2.
function Odtworz2_Callback(hObject, eventdata, handles)
% hObject    handle to Odtworz2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Hz;
global Z;

sound(Z,Hz);

% --- Executes on button press in Odwtorz3.
function Odwtorz3_Callback(hObject, eventdata, handles)
% hObject    handle to Odwtorz3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Hz;
global A;
global Y;

sound(A+Y,Hz);

% --- Executes on button press in Odwtorz4.
function Odwtorz4_Callback(hObject, eventdata, handles)
% hObject    handle to Odwtorz4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global YY;
global Czestotliwosc_Value;

Czestotliwosc_Value = get(handles.CzestotliwoscS,'Value');
sound(YY,Czestotliwosc_Value);


% --- Executes on button press in Wyczysc1.
function Wyczysc1_Callback(hObject, eventdata, handles)
% hObject    handle to Wyczysc1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

axes(handles.axes3);
cla(handles.axes3);
axis([0 5 -0.5 0.5]);

% --- Executes on button press in Wyczysc2.
function Wyczysc2_Callback(hObject, eventdata, handles)
% hObject    handle to Wyczysc2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

axes(handles.axes4);
cla(handles.axes4);
axis([0 5 -0.5 0.5]);

% --- Executes on button press in Wyczysc3.
function Wyczysc3_Callback(hObject, eventdata, handles)
% hObject    handle to Wyczysc3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

axes(handles.axes5);
cla(handles.axes5);
axis([0 5 -0.5 0.5]);

% --- Executes on button press in Wyczysc4.
function Wyczysc4_Callback(hObject, eventdata, handles)
% hObject    handle to Wyczysc4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

axes(handles.axes6);
cla(handles.axes6);
axis([0 5 -0.5 0.5]);

% --- Executes on slider movement.
function AmplitudaS_Callback(hObject, eventdata, handles)
% hObject    handle to AmplitudaS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

global Amplituda_Value;
global Y;
global YY;
global t;
global Czestotliwosc_Value;



Czestotliwosc_Value = get(handles.CzestotliwoscS,'Value');
set(handles.CzestotliwoscV,'String',num2str(Czestotliwosc_Value));
Amplituda_Value = get(hObject,'Value');
set(handles.AmplitudaV,'String',num2str(Amplituda_Value));
YY = Y*Amplituda_Value;
t = 0:1/Czestotliwosc_Value:length(YY)/Czestotliwosc_Value - 1/Czestotliwosc_Value;
axes(handles.axes6);
plot(t,YY);
ylim([-0.5 0.5]);
xlim([0 5])

% --- Executes during object creation, after setting all properties.
function AmplitudaS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AmplitudaS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

set(hObject, 'Min', 0.1);
set(hObject, 'Max', 10);
set(hObject, 'SliderStep', [0.01 0.1]);
set(hObject, 'Value', 1);


% --- Executes on slider movement.
function CzestotliwoscS_Callback(hObject, eventdata, handles)
% hObject    handle to CzestotliwoscS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

global Czestotliwosc_Value;
global YY;
global t;

Czestotliwosc_Value = get(hObject,'Value');
set(handles.CzestotliwoscV,'String',num2str(Czestotliwosc_Value));
t = 0:1/Czestotliwosc_Value:length(YY)/Czestotliwosc_Value - 1/Czestotliwosc_Value;
axes(handles.axes6);
plot(t,YY);
ylim([-0.5 0.5])
xlim([0 5])


% --- Executes during object creation, after setting all properties.
function CzestotliwoscS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CzestotliwoscS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

set(hObject, 'Min', 1);
set(hObject, 'Max', 88200);
set(hObject, 'SliderStep', [0.001 0.01]);
set(hObject, 'Value', 44100);



function AmplitudaV_Callback(hObject, eventdata, handles)
% hObject    handle to AmplitudaV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of AmplitudaV as text
%        str2double(get(hObject,'String')) returns contents of AmplitudaV as a double

global Amplituda_Value;

Amplituda_Value = get(hObject,'Value');

% --- Executes during object creation, after setting all properties.
function AmplitudaV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AmplitudaV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CzestotliwoscV_Callback(hObject, eventdata, handles)
% hObject    handle to CzestotliwoscV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CzestotliwoscV as text
%        str2double(get(hObject,'String')) returns contents of CzestotliwoscV as a double

global Czestotliwosc_Value;

Czestotliwosc_Value = get(hObject,'Value');

% --- Executes during object creation, after setting all properties.
function CzestotliwoscV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CzestotliwoscV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% now is definition of m-file slider1

function Zombiez
hold on
figure(1);
a = 33;
b = 33; % 33m*33m=1089m^2 <= to b�dzie powierzchnia sali Europarlamentu
axis([0 a 0 b]);
title('Sala obrad Parlamentu Europejskiego');
xlabel('D�ugo�� sali [m]');
ylabel('Szereko�� sali [m]');

NZ = 4; % Liczba pocz�tkowa Zombie (przy innej liczbie Zombie, nale�y 
%zmieni� plan ataku zombie (linijka 36-37). Poniewa� je�li ustalamy, 
%�e Zombie atakuj� z 4 r�nych stron to ich lokalizacja startowa jest
%wprowadzona r�cznie, przez co je�li damy NZ = 5, to wyskoczy nam b��d w 
%38 i 39 linijce. (tam wspo�rz�dne X i Y s� przeznaczone dla 4 "zombiak�w".
%Je�li zmienimy plan ataku, czyli wstawimy "%" w linijce 38 i 39, a
%usuniemy "%" przed linijkami 36 i 37, to zombie bed� atakowa� z jednego
%rogu, a ich lokalizacja startowa b�dzie losowana z przedzia�u (0,1).

NH = 750; % Liczba pocz�tkowa Europos��w
V = 0.5; % Pr�dko�� w m/s, z jak� poruszaj� si� Zombie
Sickness = 0.45; % 45% szans na zombifikacj� w przypadku spotkanie Zombie
Death = 0.45; % 45% szans na �mier� w przypadku spotkania Zombie
Murder = 0.1; % 10% szans na pokonanie zombie w przypadku spotkania
SicknessCounter = 0; % Pocz�tkowa warto�� wskrzeszonych Europos��w
DeathCounter = 0; % Pocz�tkowa warto�� martwych Europos��w
MurderCounter = 0; % Pocz�tkowa warto�� mord�w na Zombie
HumansLeft = NH; % Liczba pozosta�ych Europos��w
StepZ = 1; 
StepH = 1;
NZMatrix(1,1) = NZ; 
NHMatrix(1,1) = NH;
TimeOfChangeZ(1,1) = 0;
TimeOfChangeH(1,1) = 0;
X = rand(NZ,2);
%X(1:end,1) = round(X(1:end,1)*1); % Wsp�rz�dne dla Zombie atakuj�cych z
%X(1:end,2) = round(X(1:end,2)*1); % tej samej strony
X(1:end,1) = [0 0 a a]; % Wsp�rz�dne dla Zombie atakuj�cych z
X(1:end,2) = [0 b b 0]; % czterech r�nych stron
x = X(1:end,1);
y = X(1:end,2);
H = rand(NH,2); % Losowe rozmieszczenie Europos��w
H(1:end,1) = round(H(1:end,1)*a);
H(1:end,2) = round(H(1:end,2)*a);
% FORMACJA OBRONNA EUROPOS��W (Aby j� aktywowa�, nale�y usun�� "%" w
% linikach: od 47 do 107, a w linijkach 42-44, wpisa� "%" na pocz�tku.
% H = [];
% for i = 1:50
%     H(i,1) = i/2+4;
%     H(i,2) = 9;
% end
% for i = 51:100
%     H(i,1) = i/2-21;
%     H(i,2) = 10;
% end
% for i = 101:150
%     H(i,1) = i/2-46;
%     H(i,2) = 11;
% end
% for i = 151:200
%     H(i,1) = i/2-71;
%     H(i,2) = 12;
% end
% for i = 201:250
%     H(i,1) = i/2-96;
%     H(i,2) = 13;
% end
% for i = 251:300
%     H(i,1) = i/2-121;
%     H(i,2) = 14;
% end
% for i = 301:350
%     H(i,1) = i/2-146;
%     H(i,2) = 15;
% end
% for i = 351:400
%     H(i,1) = i/2-171;
%     H(i,2) = 16;
% end
% for i = 401:450
%     H(i,1) = i/2-196;
%     H(i,2) = 17;
% end
% for i = 451:500
%     H(i,1) = i/2-221;
%     H(i,2) = 18;
% end
% for i = 501:550
%     H(i,1) = i/2-246;
%     H(i,2) = 19;
% end
% for i = 551:600
%     H(i,1) = i/2-271;
%     H(i,2) = 20;
% end
% for i = 601:650
%     H(i,1) = i/2-296;
%     H(i,2) = 21;
% end
% for i = 651:700
%     H(i,1) = i/2-321;
%     H(i,2) = 22;
% end
% for i = 701:750
%     H(i,1) = i/2-346;
%     H(i,2) = 23;
% end

Hx = H(1:end,1);
Hy = H(1:end,2);
Xplot = plot(x,y,'k.','markersize',50);
Xplot; % Rysuje� pocz�tkowe miejsce Zombie
plot(Hx,Hy,'b.','markersize',50); % Rysuj� Europos��w
Zplot = plot(0,0,'k.','markersize',50); % Rezerwuj� t� zmienn� na p�niej

%t jest czasem kt�ry potrzebuje oddzia� na dotarcie do sali obrad
%je�li ustawimy wystarczaj�co du�e t (np. t:10000). Program b�dzie dzia�a�, dop�ki nie zgin� wszyscy
%europos�owie/zombie.
for t = 1:360
    for n = 1:NZ % dla ka�dego Zombie od 1 do NZ ustalamy jego nowe po�o�enie
        RNG = floor(rand(1,1)*9); % losuj� jak poruszy si� Zombie 
        if RNG == 0 || RNG == 9            
        elseif RNG == 1
            X(n) = X(n)-V;
            X(n+NZ) = X(n+NZ)-V;
        elseif RNG == 2
            X(n+NZ) = X(n+NZ)-V;
        elseif RNG == 3
            X(n) = X(n)+V;
            X(n+NZ) = X(n+NZ)-V;
        elseif RNG == 4
            X(n) = X(n)-V;
        elseif RNG == 5 %9
            X(n) = X(n)+V;
            X(n+NZ) = X(n+NZ)+V;
        elseif RNG == 6
            X(n) = X(n)+V;
        elseif RNG == 7
            X(n) = X(n)-V;
            X(n+NZ) = X(n+NZ)+V;
        elseif RNG == 8
            X(n+NZ) = X(n+NZ)+V;
        end
        if X(n) < 0 % zadaniem tej p�tli jest dopilnowanie, aby Zombie
            X(n) = X(n)+V; % nie wyszed� "przez �ciane" sali
            if X(n+NZ) < 0
                X(n+NZ) = X(n+NZ)+V;
            elseif X(n+NZ) > b
                X(n+NZ) = X(n+NZ)-V;
            else
            end            
        elseif X(n+NZ) < 0
            X(n+NZ) = X(n+NZ)+V;
            if X(n) < 0
                X(n) = X(n)+V;
            elseif X(n) > a
                X(n) = X(n)-V;
            else
            end
        elseif X(n) > a
            X(n) = X(n)-V;
            if X(n+NZ) < 0
                X(n+NZ) = X(n+NZ)+V;
            elseif X(n+NZ) > b
                X(n+NZ) = X(n+NZ)-V;
            else
            end
        elseif X(n+NZ) > b
            X(n+NZ) = X(n+NZ)-V;
            if X(n) < 0
                X(n) = X(n)+V;
            elseif X(n) > a
                X(n) = X(n)-V;
            else
            end
        else
        end
    end
    for i = 1:length(X) % sprawdzam czy Zombie spotka� na swojej drodze
        for j = 1:length(H) % Europos�a, nast�pnie losuj�, czy Zombie
            if X(i,1) == H(j,1) % zabi�, zgin��, czy si� rozmno�y�
                if X(i,2) == H(j,2)
                    Fight = rand(1,1);
                    if Fight > Murder 
                        if Fight > Murder+Sickness
                            NH = NH-1;
                            DeathCounter = DeathCounter+1;
                            plot(H(j,1),H(j,2),'r.','markersize',50);
                            H(j,1:2) = [-1,-1]; % �mier� europos�a - podczas symulacji
                            display('Death'); % mo�emy �ledzi� przebieg star� 
                            HumansLeft = HumansLeft-1; % europos��w z zombie w Command Window
                            DeathCounterMatrix(1,DeathCounter) = DeathCounter;
                            TimeOfDeath(1,DeathCounter) = t;
                            StepH = StepH+1;
                            NHMatrix(1,StepH) = NH;
                            TimeOfChangeH(1,StepH) = t;
                        else
                            NH = NH-1;
                            SicknessCounter = SicknessCounter+1;
                            plot(H(j,1),H(j,2),'r.','markersize',50);
                            NZ = NZ+1;
                            X(NZ+1,1:2) = [H(j,1),H(j,2)];
                            H(j,1:2) = [-1,-1];
                            display('Sickness'); % europose� zainfekowany
                            HumansLeft = HumansLeft-1;
                            SicknessCounterMatrix(1,SicknessCounter) = SicknessCounter;
                            TimeOfSickness(1,SicknessCounter) = t;
                            StepZ = StepZ+1;
                            StepH = StepH+1;
                            NZMatrix(1,StepZ) = NZ;
                            NHMatrix(1,StepH) = NH;
                            TimeOfChangeZ(1,StepZ) = t;
                            TimeOfChangeH(1,StepH) = t;
                        end
                    else
                        MurderCounter = MurderCounter+1;
                        NZ = NZ-1;
                        display('Murder'); % �mier� zombie
                        MurderCounterMatrix(1,MurderCounter) = MurderCounter;
                        TimeOfMurder(1,MurderCounter) = t;
                        StepZ = StepZ+1;
                        NZMatrix(1,StepZ) = NZ;
                        TimeOfChangeZ(1,StepZ) = t;
                    end
                else
                end
            else
            end
        end
    end        
        
    delete(Xplot);
    delete(Zplot);
    Zplot = plot(X(1:NZ,1),X(1:NZ,2),'k.','markersize',50);
    Zplot;
    if HumansLeft == 0 % je�li liczba ludzi lub zombie spadnie do zera
        display(t); % program ko�czy prac� i wy�wietla wynik
        break
    elseif NZ == 0
        display(t);
        break
    end
    pause(0.1); % dzi�ki 0.1s pauzie, jeste�my w stanie zobaczy� ruch Zombie
end
display(DeathCounter); % wy�wietlam liczb� martwych Europos��w
display(SicknessCounter); % wy�wietlam liczb� wskrzeszonych Europos��w jako Zombie
display(MurderCounter); % wy�wietlam liczb� martych Zombie
Uratowani_Poslowie = HumansLeft;
display(Uratowani_Poslowie);
figure(2);
subplot(2,2,1)
plot(TimeOfChangeZ,NZMatrix,'k.');
hold on
plot(TimeOfChangeH,NHMatrix,'b.');
title('Liczba Europos��w I Zombie W Zale�no��i Od Czasu');
xlabel('Czas [s]');
ylabel('Liczba Europos��w/Zombie');
legend('Zombie','Europos�owie');

subplot(2,2,2)
plot(TimeOfDeath,DeathCounterMatrix,'r.');
title('Wykres Zabitych Ludzi Wzgl�dem Czasu');
xlabel('Czas [s]');
ylabel('Ilo�� Zabitych Ludzi (Nie Wliczaj�c O�ywie�c�w)');
axis([0 t 0 DeathCounter+0.1]);

subplot(2,2,3)
plot(TimeOfSickness,SicknessCounterMatrix,'k.');
title('Wykres O�ywionych Ludzi Jako Zombie Wzgl�dem Czasu');
xlabel('Czas [s]');
ylabel('Ilo�� O�ywie�c�w');
axis([0 t 0 SicknessCounter+0.1]);

subplot(2,2,4)
plot(TimeOfMurder,MurderCounterMatrix,'b.');
title('Wykres Zabitych Zombie Wzgl�dem Czasu');
xlabel('Czas [s]');
ylabel('Ilo�� Zabitych Zombie');
axis([0 t 0 MurderCounter+0.1]);